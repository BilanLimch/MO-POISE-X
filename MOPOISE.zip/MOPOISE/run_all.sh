#!/bin/bash
# Run every (algorithm, run) unit plus the per-fold filter baselines, skipping
# units whose result file already exists. Set JOBS to run several units at
# once (each unit uses OMP_NUM_THREADS threads). Example:
#   JOBS=8 OMP_NUM_THREADS=2 ./run_all.sh            # NSGA2 NSGA3 SMSEMOA
#   JOBS=4 OMP_NUM_THREADS=4 ./run_all.sh NSGA2      # a subset
set -euo pipefail
cd "$(dirname "$0")"
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-2} MKL_NUM_THREADS=${OMP_NUM_THREADS:-2} OPENBLAS_NUM_THREADS=${OMP_NUM_THREADS:-2}
JOBS=${JOBS:-1}
ALGOS=$(python -c 'from mopoise.search import algorithm_names; print(" ".join(algorithm_names()))')
[ $# -ge 1 ] && ALGOS="$*"
mkdir -p logs
for FOLD in $(seq 0 4); do
  [ -f "results/baselines/fold${FOLD}.json" ] || python -m mopoise.baselines --fold "$FOLD" > "logs/baselines-${FOLD}.log" 2>&1
  for M in l1 mrmr; do
    [ -f "results/baselines_${M}/fold${FOLD}.json" ] || python -m mopoise.baselines --fold "$FOLD" --method "$M" > "logs/baselines_${M}-${FOLD}.log" 2>&1
  done
done
running=0
for ALG in $ALGOS; do
  for RUN in $(seq 0 19); do
    python -m mopoise.nested_cv --algorithm "$ALG" --run "$RUN" > "logs/unit-${ALG}-${RUN}.log" 2>&1 &
    running=$((running + 1))
    if [ "$running" -ge "$JOBS" ]; then wait -n; running=$((running - 1)); fi
  done
done
wait
echo "all units finished"
