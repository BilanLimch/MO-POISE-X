"""MO-POISE: Multi-Objective Plug-and-play Optimizer for Imbalance-aware Subtyping of Endometrial cancer."""
