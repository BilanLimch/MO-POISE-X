"""
Fold-internal candidate-feature-pool construction.

Everything in here is fitted on the *outer training fold only* and then
applied to any other rows (outer test fold, inner CV splits) via
``FeaturePool.transform``. Nothing here may see the full dataset's labels:
callers pass ``train_idx`` and the pool is built from those rows alone.

Per omics block (rna / mirna / meth / cnv), on the training rows:
  1. drop features constant on the training rows (they carry no information
     for this fold and break ANOVA);
  2. ``mut`` only: keep genes mutated in >= ``min_mutation_frac`` of training
     patients (rare binary features are pure noise for a wrapper search);
  3. rank the rest by the chosen univariate score and keep the top
     ``k_per_block`` -- ``"anova"`` (one-way F statistic vs. the subtype
     label, i.e. a differential-analysis ranking) or
     ``"variance"`` (label-free).

Clinical block: never filtered; ``age`` / ``figo_stage`` NaNs are imputed
with the training-fold median.

The resulting pool is the ``N`` of the (N+5)-dimensional search space; the
classifier-selection bits are appended by ``feature_selection.py``, not here.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from sklearn.feature_selection import f_classif

from mopoise.data import UcecDataset

OMICS_BLOCKS: tuple[str, ...] = ("rna", "mirna", "meth", "cnv", "mut")


@dataclass
class PrefilterConfig:
    k_per_block: int | dict[str, int] = 500
    method: str = "anova"              # "anova" | "variance"
    min_mutation_frac: float = 0.03
    include_clinical: bool = True

    def k_for(self, block: str) -> int:
        return self.k_per_block[block] if isinstance(self.k_per_block, dict) else self.k_per_block


@dataclass
class FeaturePool:
    """A fitted candidate pool: which columns of which block, plus clinical imputation."""
    columns: dict[str, np.ndarray]                    # block -> selected column indices
    feature_names: np.ndarray                          # (N,) "block:feature"
    clinical_fill: dict[int, float] = field(default_factory=dict)  # clin column -> train median
    block_slices: dict[str, slice] = field(default_factory=dict)

    @property
    def n_features(self) -> int:
        return len(self.feature_names)

    def transform(self, ds: UcecDataset, idx: np.ndarray) -> np.ndarray:
        parts = []
        for block, cols in self.columns.items():
            X = ds.blocks[block].X[np.ix_(idx, cols)]
            if block == "clin" and self.clinical_fill:
                X = X.copy()
                for j, v in self.clinical_fill.items():
                    col = X[:, list(cols).index(j)]
                    col[np.isnan(col)] = v
            parts.append(X)
        return np.concatenate(parts, axis=1).astype(np.float32, copy=False)


def _score(X: np.ndarray, y: np.ndarray, method: str) -> np.ndarray:
    if method == "variance":
        return X.var(axis=0)
    if method == "anova":
        F, _ = f_classif(X, y)
        return np.nan_to_num(F, nan=-np.inf)
    raise ValueError(f"unknown prefilter method {method!r}")


def fit_feature_pool(ds: UcecDataset, train_idx: np.ndarray, cfg: PrefilterConfig) -> FeaturePool:
    y_tr = ds.y[train_idx]
    columns: dict[str, np.ndarray] = {}
    names: list[str] = []

    for block in OMICS_BLOCKS:
        if block not in ds.blocks:
            continue
        X_tr = ds.blocks[block].X[train_idx]
        keep = X_tr.std(axis=0) > 0
        if block == "mut":
            keep &= X_tr.mean(axis=0) >= cfg.min_mutation_frac
        cand = np.flatnonzero(keep)
        k = min(cfg.k_for(block), len(cand))
        scores = _score(X_tr[:, cand], y_tr, cfg.method)
        top = cand[np.argsort(-scores, kind="stable")[:k]]
        top = np.sort(top)
        columns[block] = top
        names.extend(f"{block}:{f}" for f in ds.blocks[block].features[top])

    fill: dict[int, float] = {}
    if cfg.include_clinical and "clin" in ds.blocks:
        clin = ds.blocks["clin"]
        cols = np.arange(clin.n_features)
        X_tr = clin.X[train_idx]
        for j in cols:
            if np.isnan(X_tr[:, j]).any():
                fill[int(j)] = float(np.nanmedian(X_tr[:, j]))
        columns["clin"] = cols
        names.extend(f"clin:{f}" for f in clin.features)

    slices, start = {}, 0
    for block, cols in columns.items():
        slices[block] = slice(start, start + len(cols))
        start += len(cols)
    return FeaturePool(columns=columns, feature_names=np.asarray(names, dtype=str),
                       clinical_fill=fill, block_slices=slices)
