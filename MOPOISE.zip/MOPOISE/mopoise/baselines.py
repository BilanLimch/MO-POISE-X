"""
Filter baseline fronts for one outer fold: every non-empty subset of data
blocks crossed with ranked or penalized panels inside that subset.

    python -m mopoise.baselines --fold 0                    # ANOVA (main baseline)
    python -m mopoise.baselines --fold 0 --method l1
    python -m mopoise.baselines --fold 0 --method mrmr
    python -m mopoise.baselines --fold 0 --synthetic

Methods, all fitted on the outer training fold of block subset B:

* ``anova`` -- for each m in ``M_GRID`` (plus m = all pool features of B),
  the m features of B with the largest ANOVA F statistic. Univariate.
* ``mrmr``  -- the first m features of a greedy mRMR ranking of B
  (relevance = ANOVA F, redundancy = mean |Pearson r| with the features
  already chosen, criterion F / redundancy; the "FCQ" variant), same m grid.
* ``l1``    -- the supports of one-vs-rest L1-penalized logistic regressions
  on z-scored features of B (union over the four classes) along a grid of
  ``L1_GRID_SIZE`` values of C, from the smallest C that selects a feature
  upward, plus the panel of all pool features of B.

mRMR and L1 account for redundancy and joint effects, so they test whether
the advantage of the evolutionary search for compact panels is more than an
advantage over a univariate ranking.

Each panel gets the same inner-CV objectives as the search
(``PanelEvaluator``, i.e. a refitted unpenalized classifier) and one
outer-test score. The rankings and supports are computed on the whole outer
training fold, so the inner error of a baseline panel is mildly optimistic;
its outer-test score is not.

A multi-objective search contributes something only if its front is better
than these on the outer test folds.
"""

from __future__ import annotations

import argparse
import itertools
import json
import warnings
from pathlib import Path

import numpy as np
import sklearn
from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_selection import f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.svm import l1_min_c

from mopoise.data import UcecDataset, load_dataset
from mopoise.nested_cv import RESULTS_DIR, SEED_BASE, outer_folds, test_metrics
from mopoise.objectives import N_CLASSES, ObjectiveConfig, PanelEvaluator, fit_predict
from mopoise.prefilter import PrefilterConfig, fit_feature_pool

METHODS = ("anova", "mrmr", "l1")
M_GRID = (1, 2, 3, 5, 10, 20, 50, 100, 200, 450)
L1_GRID_SIZE = 40
L1_C_RANGE = 10 ** 2.0          # largest C / smallest C; dense at small supports

# scikit-learn 1.8 deprecated ``penalty`` in favour of ``l1_ratio``.
_SK_NEW = tuple(int(v) for v in sklearn.__version__.split(".")[:2]) >= (1, 8)
_L1_KW = {"l1_ratio": 1.0} if _SK_NEW else {"penalty": "l1"}


def baseline_dir(method: str) -> str:
    return "baselines" if method == "anova" else f"baselines_{method}"


def _zscore(X: np.ndarray) -> np.ndarray:
    sd = X.std(axis=0)
    return (X - X.mean(axis=0)) / np.where(sd > 0, sd, 1.0)


def mrmr_order(Z: np.ndarray, F: np.ndarray, n: int) -> np.ndarray:
    """Greedy FCQ mRMR on z-scored columns Z: first n column indices in order of selection."""
    n = min(n, Z.shape[1])
    order = [int(np.argmax(F))]
    red = np.zeros(Z.shape[1])                      # running sum of |r| with the chosen columns
    chosen = np.zeros(Z.shape[1], dtype=bool)
    chosen[order[0]] = True
    for k in range(1, n):
        red += np.abs(Z.T @ Z[:, order[-1]]) / len(Z)
        crit = F / np.maximum(red / k, 1e-6)
        crit[chosen] = -np.inf
        j = int(np.argmax(crit))
        order.append(j)
        chosen[j] = True
    return np.array(order, dtype=int)


def l1_supports(Z: np.ndarray, y: np.ndarray, random_state: int, n_grid: int = L1_GRID_SIZE) -> list[np.ndarray]:
    """Supports (column indices) of one-vs-rest L1 logistic regressions along a C grid."""
    c_min = min(l1_min_c(Z, y == c, loss="log") for c in range(N_CLASSES) if 0 < (y == c).sum() < len(y))
    out = []
    for C in c_min * np.logspace(0, np.log10(L1_C_RANGE), n_grid):
        coef = np.zeros(Z.shape[1], dtype=bool)
        for c in range(N_CLASSES):
            if not 0 < (y == c).sum() < len(y):
                continue
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", ConvergenceWarning)
                clf = LogisticRegression(C=C, solver="liblinear", max_iter=2000, random_state=random_state,
                                         **_L1_KW).fit(Z, y == c)
            coef |= clf.coef_.ravel() != 0
        if coef.any():
            out.append(np.flatnonzero(coef))
    return out


def candidate_panels(method: str, X: np.ndarray, y: np.ndarray, F: np.ndarray, cols: np.ndarray,
                     m_grid, random_state: int) -> list[tuple[int, np.ndarray]]:
    """(m, column indices) of the panels of one block subset; m = panel size (or C-grid index for l1)."""
    sizes = sorted({m for m in m_grid if m < len(cols)} | {len(cols)})
    if method == "anova":
        ranked = cols[np.argsort(-F[cols], kind="stable")]
        return [(m, ranked[:m]) for m in sizes]
    Z = _zscore(X[:, cols])
    if method == "mrmr":
        n_rank = max([m for m in sizes if m < len(cols)], default=0)
        ranked = cols[mrmr_order(Z, np.maximum(F[cols], 0.0), n_rank)] if n_rank else cols[:0]
        return [(m, ranked[:m]) for m in sizes if m < len(cols)] + [(len(cols), cols)]
    if method == "l1":
        return [(len(s), cols[s]) for s in l1_supports(Z, y, random_state)] + [(len(cols), cols)]
    raise ValueError(f"unknown baseline method: {method!r}")


def run_baselines(fold: int, prefilter: PrefilterConfig | None = None, objective: ObjectiveConfig | None = None,
                  ds: UcecDataset | None = None, out_dir: Path = RESULTS_DIR, m_grid=M_GRID,
                  method: str = "anova") -> dict:
    prefilter = prefilter or PrefilterConfig(k_per_block=500)
    objective = objective or ObjectiveConfig(random_state=SEED_BASE)
    ds = ds if ds is not None else load_dataset()
    train_idx, test_idx = outer_folds(ds)[fold]
    y_tr, y_te = ds.y[train_idx], ds.y[test_idx]
    pool = fit_feature_pool(ds, train_idx, prefilter)
    X_tr, X_te = pool.transform(ds, train_idx), pool.transform(ds, test_idx)
    evaluator = PanelEvaluator(X_tr, y_tr, pool.block_slices, objective)

    F, _ = f_classif(X_tr, y_tr)
    F = np.nan_to_num(F, nan=-np.inf)
    blocks = list(pool.block_slices)
    rows, seen = [], set()
    for r in range(1, len(blocks) + 1):
        for subset in itertools.combinations(blocks, r):
            cols = np.concatenate([np.arange(pool.block_slices[b].start, pool.block_slices[b].stop) for b in subset])
            for m, idx in candidate_panels(method, X_tr, y_tr, F, cols, m_grid, objective.random_state):
                mask = np.zeros(pool.n_features, dtype=bool)
                mask[idx] = True
                key = np.packbits(mask).tobytes()
                if key in seen:     # same panel reached from another block subset
                    continue
                seen.add(key)
                s = evaluator.score(mask)
                pred, proba = fit_predict(objective.classifier, X_tr[:, mask], y_tr, X_te[:, mask], objective.random_state)
                rows.append({"blocks": list(subset), "m": int(m), "used_blocks": evaluator.active_blocks(mask),
                             "inner_error": s.error, "inner_error_se": s.error_se,
                             "assay_cost": s.cost, "size": s.size, "test": test_metrics(y_te, pred, proba)})

    result = {"fold": fold, "method": method, "N": int(pool.n_features), "classifier": objective.classifier,
              "k_per_block": prefilter.k_per_block, "panels": rows}
    out_path = Path(out_dir) / baseline_dir(method) / f"fold{fold}.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(result, f, indent=1)
    print(f"fold{fold} {method}: {len(rows)} baseline panels -> {out_path}")
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--fold", type=int, required=True)
    ap.add_argument("--method", default="anova", choices=METHODS)
    ap.add_argument("--k-per-block", type=int, default=500)
    ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--out", type=Path, default=RESULTS_DIR)
    a = ap.parse_args()
    ds = None
    if a.synthetic:
        from mopoise.synthetic import make_synthetic_dataset
        ds = make_synthetic_dataset()
    run_baselines(a.fold, PrefilterConfig(k_per_block=a.k_per_block), ds=ds, out_dir=a.out, method=a.method)
