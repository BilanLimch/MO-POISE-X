"""
One unit of the multi-objective nested-CV experiment:
    one algorithm  x  one outer fold  x  one repeat seed.

    python -m mopoise.nested_cv --algorithm NSGA2 --run 7
    python -m mopoise.nested_cv --algorithm NSGA2 --run 0 --synthetic --max-evals 300   # no data needed

The outer partition, the run -> (fold, seed) mapping and the prefilter are
those of POISE-X, so run i here is paired with run i of every POISE-X
instantiation (same fold, same inner-CV seed).

Inside the outer training fold only: prefilter (ANOVA top-k per block), the
three-objective search, and the training-side panel choice
(``selection.py``). Afterwards every panel on the final non-dominated set is
refitted on the whole outer training fold and scored once on the outer test
fold. The test scores of the whole front are reported to draw the
test-side trade-off curve; only the panels picked by the training-side rules
are "selected" results.
"""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import numpy as np
from pymoo.optimize import minimize
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold

from mopoise import moeas
from mopoise.data import CLASS_NAMES, UcecDataset, load_dataset
from mopoise.objectives import ObjectiveConfig, PanelEvaluator, fit_predict
from mopoise.moeas.base import best
from mopoise.prefilter import PrefilterConfig, fit_feature_pool
from mopoise.search import HypervolumeCallback, algorithm_names, PanelProblem, build_algorithm, hypervolume
from mopoise.selection import nondominated, one_se_rule, per_cost_rule

OUTER_SPLIT_SEED = 0
K_OUTER = 5
R_REPEATS = 4
N_RUNS = K_OUTER * R_REPEATS
SEED_BASE, SEED_STEP = 2026, 98
STANDARD_MAX_EVALS = 5_000
STANDARD_POP_SIZE = 50
RESULTS_DIR = Path(os.environ.get("UCEC_RESULTS_DIR", Path(__file__).resolve().parents[1] / "results"))


def unit_from_run(i: int) -> tuple[int, int]:
    if not 0 <= i < N_RUNS:
        raise ValueError(f"run index must be in 0..{N_RUNS - 1}, got {i}")
    return i // R_REPEATS, SEED_BASE + SEED_STEP * i


def outer_folds(ds: UcecDataset) -> list[tuple[np.ndarray, np.ndarray]]:
    skf = StratifiedKFold(n_splits=K_OUTER, shuffle=True, random_state=OUTER_SPLIT_SEED)
    return list(skf.split(np.zeros(ds.n), ds.y))


def test_metrics(y_te, pred, proba) -> dict:
    return {
        "macro_f1": float(f1_score(y_te, pred, average="macro", labels=range(4))),
        "macro_auc": float(roc_auc_score(y_te, proba, multi_class="ovr", average="macro", labels=range(4))),
        "accuracy": float(accuracy_score(y_te, pred)),
        "per_class_f1": dict(zip(CLASS_NAMES, f1_score(y_te, pred, average=None, labels=range(4)).tolist())),
    }


def _search(algorithm, evaluator, max_evals, pop_size, seed, block_slices, density=(0.005, 0.2)):
    """Run one search; return (final non-dominated masks, evaluations used, HV curve)."""
    if algorithm in moeas.REGISTRY:
        run, kind = moeas.get_run(algorithm)
        problem = (moeas.PanelRealProblem if kind == "real" else moeas.PanelBinaryProblem)(evaluator, max_evals)
        problem.density = density
        curve: list[tuple[int, float]] = []

        def callback(p, X, F):
            F = np.asarray(F)[best(F)]
            F = F[~(F == p.worst).all(axis=1)]
            curve.append((int(p.n_evals), hypervolume(F, evaluator.total_cost)))

        X, F = run(problem, pop_size, np.random.default_rng(seed), callback=callback)
        return problem.masks(X)[best(F)], problem.n_evals, curve
    callback = HypervolumeCallback(evaluator.total_cost)
    res = minimize(PanelProblem(evaluator), build_algorithm(algorithm, block_slices, pop_size=pop_size, density=density),
                   ("n_evals", max_evals), seed=seed, callback=callback, verbose=False)
    masks = np.atleast_2d(np.asarray(res.X, dtype=bool))
    return masks, res.algorithm.evaluator.n_eval, callback.curve


def run_unit(algorithm: str, fold: int, seed: int, max_evals: int = STANDARD_MAX_EVALS,
             pop_size: int = STANDARD_POP_SIZE, prefilter: PrefilterConfig | None = None,
             objective: ObjectiveConfig | None = None, out_dir: Path = RESULTS_DIR,
             ds: UcecDataset | None = None, force: bool = False,
             density: tuple[float, float] = (0.005, 0.2), tag: str = "") -> dict:
    out_path = Path(out_dir) / (algorithm + tag) / f"fold{fold}_seed{seed}.json"
    if out_path.exists() and not force:
        print(f"exists, skipping: {out_path}")
        return json.load(open(out_path))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    prefilter = prefilter or PrefilterConfig(k_per_block=500)
    objective = objective or ObjectiveConfig()
    objective.random_state = seed

    t_start = time.time()
    ds = ds if ds is not None else load_dataset()
    train_idx, test_idx = outer_folds(ds)[fold]
    y_tr, y_te = ds.y[train_idx], ds.y[test_idx]
    pool = fit_feature_pool(ds, train_idx, prefilter)
    X_tr, X_te = pool.transform(ds, train_idx), pool.transform(ds, test_idx)

    evaluator = PanelEvaluator(X_tr, y_tr, pool.block_slices, objective)
    t_search = time.time()
    masks, evals_used, hv_curve = _search(algorithm, evaluator, max_evals, pop_size, seed, pool.block_slices, density)
    search_seconds = time.time() - t_search

    masks = np.unique(masks[masks.any(axis=1)], axis=0)
    scores = [evaluator.score(m) for m in masks]
    err = np.array([s.error for s in scores])
    se = np.array([s.error_se for s in scores])
    cost = np.array([s.cost for s in scores])
    size = np.array([s.size for s in scores])

    front = []
    for m, s in zip(masks, scores):
        pred, proba = fit_predict(objective.classifier, X_tr[:, m], y_tr, X_te[:, m], seed)
        front.append({
            "inner_error": s.error, "inner_error_se": s.error_se, "inner_scores": s.scores.tolist(),
            "assay_cost": s.cost, "size": s.size, "blocks": evaluator.active_blocks(m),
            "selected_per_block": {b: int(m[sl].sum()) for b, sl in pool.block_slices.items()},
            "features": pool.feature_names[m].tolist(),
            "test": test_metrics(y_te, pred, proba),
        })
    test_err = np.array([1 - f["test"]["macro_f1"] for f in front])
    F_inner = np.column_stack([err, cost, size / pool.n_features])
    F_test = np.column_stack([test_err, cost, size / pool.n_features])

    one_se = one_se_rule(err, se, cost, size)
    per_cost = per_cost_rule(err, se, cost, size)
    result = {
        "algorithm": algorithm + tag, "fold": fold, "seed": seed,
        "protocol": {"pop_size": pop_size, "max_evals": max_evals, "k_per_block": prefilter.k_per_block,
                     "classifier": objective.classifier, "k_inner": objective.k_inner,
                     "n_inner_repeats": objective.n_inner_repeats, "assay_cost": objective.assay_cost,
                     "k_outer": K_OUTER, "outer_split_seed": OUTER_SPLIT_SEED,
                     "init_density": list(density)},
        "n_train": int(len(train_idx)), "n_test": int(len(test_idx)), "N": int(pool.n_features),
        "evals_used": int(evals_used), "distinct_panels_scored": evaluator.n_model_evals,
        "front": front,
        "selected": {"one_se": one_se, "per_cost": {str(c): i for c, i in per_cost.items()}},
        "hypervolume": {"inner": hypervolume(F_inner, evaluator.total_cost),
                        "test": hypervolume(F_test[nondominated(F_test)], evaluator.total_cost)},
        "hv_curve": hv_curve,
        "search_seconds": search_seconds, "total_seconds": time.time() - t_start,
    }
    with open(out_path, "w") as f:
        json.dump(result, f, indent=1)

    s = front[one_se]
    print(f"{algorithm} fold{fold} seed{seed}: front={len(front)} HV inner={result['hypervolume']['inner']:.3f} "
          f"test={result['hypervolume']['test']:.3f} | one-SE pick: cost={s['assay_cost']:g} |S|={s['size']} "
          f"blocks={s['blocks']} test macro-F1={s['test']['macro_f1']:.3f} [{search_seconds/60:.1f} min search]")
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--algorithm", required=True, choices=list(algorithm_names()))
    ap.add_argument("--run", type=int, help=f"run index 0..{N_RUNS - 1}: sets --fold and --seed per protocol")
    ap.add_argument("--fold", type=int)
    ap.add_argument("--seed", type=int)
    ap.add_argument("--max-evals", type=int, default=STANDARD_MAX_EVALS)
    ap.add_argument("--pop-size", type=int, default=STANDARD_POP_SIZE)
    ap.add_argument("--k-per-block", type=int, default=500)
    ap.add_argument("--classifier", default="LR", choices=["LR", "SVM", "RF", "KNN"])
    ap.add_argument("--synthetic", action="store_true", help="use synthetic data (smoke runs)")
    ap.add_argument("--out", type=Path, default=RESULTS_DIR)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--density-max", type=float, default=0.2, help="upper end of the initial per-block density")
    ap.add_argument("--tag", default="", help="suffix of the result directory (sensitivity analyses)")
    a = ap.parse_args()
    if a.run is not None:
        a.fold, a.seed = unit_from_run(a.run)
    elif a.fold is None or a.seed is None:
        ap.error("give --run, or both --fold and --seed")
    ds = None
    if a.synthetic:
        from mopoise.synthetic import make_synthetic_dataset
        ds = make_synthetic_dataset()
    run_unit(a.algorithm, a.fold, a.seed, a.max_evals, a.pop_size, PrefilterConfig(k_per_block=a.k_per_block),
             ObjectiveConfig(classifier=a.classifier), a.out, ds, a.force,
             density=(0.005, a.density_max), tag=a.tag)
