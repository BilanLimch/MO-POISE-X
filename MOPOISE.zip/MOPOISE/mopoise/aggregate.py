"""
Collect the per-unit JSON files into tables, statistics and figures.

    python -m mopoise.aggregate                 # all algorithms found under results/
    python -m mopoise.aggregate --out results/summary

Per run: test-side hypervolume of the final front (primary end point),
inner hypervolume, the panel picked by the training-side one-SE rule, and
the panel picked for every assay budget. Per fold: the same quantities for
the filter baseline front. Statistics: Friedman test over algorithms with
the twenty runs as blocks (run i of every algorithm shares fold and seed)
and with the five fold means as blocks; Wilcoxon signed-rank tests against
the algorithm with the highest mean test hypervolume, Holm-adjusted.
"""

from __future__ import annotations

import argparse
import glob
import json
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import friedmanchisquare, wilcoxon

from mopoise.baselines import METHODS, baseline_dir
from mopoise.nested_cv import RESULTS_DIR, outer_folds
from mopoise.search import hypervolume
from mopoise.selection import nondominated, one_se_rule, per_cost_rule

BUDGETS = (0, 1, 2, 3, 4, 5)
SIZE_CAPS = (5, 10, 20, 50, 100)
TOTAL_COST = 5.0


def load_runs(results: Path) -> pd.DataFrame:
    rows = []
    for f in sorted(glob.glob(str(results / "*" / "fold*_seed*.json"))):
        r = json.load(open(f))
        fr = r["front"]
        err = np.array([p["inner_error"] for p in fr]); se = np.array([p["inner_error_se"] for p in fr])
        cost = np.array([p["assay_cost"] for p in fr]); size = np.array([p["size"] for p in fr])
        sel = fr[r["selected"]["one_se"]]
        pc = per_cost_rule(err, se, cost, size)
        row = {
            "algorithm": r["algorithm"], "fold": r["fold"], "seed": r["seed"], "run": (r["seed"] - 2026) // 98,
            "hv_test": r["hypervolume"]["test"], "hv_inner": r["hypervolume"]["inner"],
            "front_size": len(fr), "evals": r["evals_used"], "minutes": r["search_seconds"] / 60,
            "sel_f1": sel["test"]["macro_f1"], "sel_auc": sel["test"]["macro_auc"], "sel_cost": sel["assay_cost"],
            "sel_size": sel["size"], "sel_blocks": "+".join(b for b in sel["blocks"]),
            **{f"sel_f1_{c}": sel["test"]["per_class_f1"][c] for c in sel["test"]["per_class_f1"]},
            "max_test_f1": max(p["test"]["macro_f1"] for p in fr),
        }
        for c in BUDGETS:
            i = _pick_at_budget(pc, c)
            row[f"budget{c}_f1"] = fr[i]["test"]["macro_f1"] if i is not None else np.nan
            row[f"budget{c}_size"] = fr[i]["size"] if i is not None else np.nan
        row.update(_size_cap_columns(err, se, cost, size, fr))
        row["_features"] = sel["features"]
        row["_blocks"] = sel["blocks"]
        row["_curve"] = r["hv_curve"]
        rows.append(row)
    return pd.DataFrame(rows)


def _size_cap_columns(err, se, cost, size, panels) -> dict:
    """Per size cap k: the one-SE panel among those with at most k features (training-side choice)."""
    out = {}
    for k in SIZE_CAPS:
        i = one_se_rule(err, se, cost, size, candidates=np.flatnonzero(size <= k))
        out[f"size{k}_f1"] = panels[i]["test"]["macro_f1"] if i is not None else np.nan
        out[f"size{k}_cost"] = panels[i]["assay_cost"] if i is not None else np.nan
    return out


def _pick_at_budget(pc: dict[float, int], c: float):
    keys = [k for k in pc if k <= c]
    return pc[max(keys)] if keys else None


def load_baselines(results: Path, method: str = "anova") -> pd.DataFrame:
    rows = []
    for f in sorted(glob.glob(str(results / baseline_dir(method) / "fold*.json"))):
        r = json.load(open(f))
        P = r["panels"]
        err = np.array([p["inner_error"] for p in P]); se = np.array([p["inner_error_se"] for p in P])
        cost = np.array([p["assay_cost"] for p in P]); size = np.array([p["size"] for p in P])
        test_err = np.array([1 - p["test"]["macro_f1"] for p in P])
        Fi = np.column_stack([err, cost, size / r["N"]]); Ft = np.column_stack([test_err, cost, size / r["N"]])
        full = [p for p in P if p["m"] == r["N"] and len(p["blocks"]) == 6]
        sel = P[one_se_rule(err, se, cost, size)]
        pc = per_cost_rule(err, se, cost, size)
        row = {"fold": r["fold"], "hv_inner": hypervolume(Fi[nondominated(Fi)], TOTAL_COST),
               "hv_test": hypervolume(Ft[nondominated(Ft)], TOTAL_COST),
               "full_pool_f1": full[0]["test"]["macro_f1"] if full else np.nan,
               "sel_f1": sel["test"]["macro_f1"], "sel_cost": sel["assay_cost"], "sel_size": sel["size"],
               "n_panels": len(P), **_size_cap_columns(err, se, cost, size, P)}
        for c in BUDGETS:
            i = _pick_at_budget(pc, c)
            row[f"budget{c}_f1"] = P[i]["test"]["macro_f1"] if i is not None else np.nan
            row[f"budget{c}_size"] = P[i]["size"] if i is not None else np.nan
        rows.append(row)
    return pd.DataFrame(rows)


def holm(p: dict[str, float]) -> dict[str, float]:
    items = sorted(p.items(), key=lambda kv: kv[1])
    m, out, running = len(items), {}, 0.0
    for i, (k, v) in enumerate(items):
        running = max(running, min(1.0, (m - i) * v))
        out[k] = running
    return out


def statistics(runs: pd.DataFrame, metric: str) -> dict:
    wide = runs.pivot(index="run", columns="algorithm", values=metric).dropna(axis=1)
    fold_wide = runs.groupby(["fold", "algorithm"])[metric].mean().unstack()[wide.columns]
    best = wide.mean().idxmax()
    p_raw = {a: float(wilcoxon(wide[a], wide[best]).pvalue) for a in wide.columns if a != best}
    return {
        "metric": metric, "best": best,
        "friedman_runs": {"stat": float(friedmanchisquare(*[wide[a] for a in wide.columns]).statistic),
                          "p": float(friedmanchisquare(*[wide[a] for a in wide.columns]).pvalue)},
        "friedman_folds": {"stat": float(friedmanchisquare(*[fold_wide[a] for a in fold_wide.columns]).statistic),
                           "p": float(friedmanchisquare(*[fold_wide[a] for a in fold_wide.columns]).pvalue)},
        "mean_rank": wide.rank(axis=1, ascending=False).mean().sort_values().to_dict(),
        "wilcoxon_vs_best_holm": holm(p_raw), "wilcoxon_vs_best_raw": p_raw,
    }


def summary_table(runs: pd.DataFrame) -> pd.DataFrame:
    g = runs.groupby("algorithm")
    t = pd.DataFrame({
        "hv_test_mean": g.hv_test.mean(), "hv_test_sd": g.hv_test.std(),
        "hv_inner_mean": g.hv_inner.mean(), "hv_inner_sd": g.hv_inner.std(),
        "front_size": g.front_size.mean(),
        "sel_f1_mean": g.sel_f1.mean(), "sel_f1_sd": g.sel_f1.std(),
        "sel_cost": g.sel_cost.mean(), "sel_size": g.sel_size.mean(), "sel_size_median": g.sel_size.median(),
        **{f"budget{c}_f1": g[f"budget{c}_f1"].mean() for c in BUDGETS},
        **{f"size{k}_f1": g[f"size{k}_f1"].mean() for k in SIZE_CAPS},
        "max_test_f1": g.max_test_f1.mean(), "minutes": g.minutes.mean(), "evals": g.evals.mean(),
    })
    return t.sort_values("hv_test_mean", ascending=False)


def baseline_comparison(runs: pd.DataFrame, base: pd.DataFrame) -> pd.DataFrame:
    """Per algorithm: paired (by fold) difference to the filter baseline front."""
    b = base.set_index("fold")
    out = {}
    for a, d in runs.groupby("algorithm"):
        diff_hv = d.hv_test.values - b.loc[d.fold, "hv_test"].values
        out[a] = {"hv_test_minus_baseline": diff_hv.mean(), "runs_above_baseline": int((diff_hv > 0).sum()),
                  "p_wilcoxon": float(wilcoxon(diff_hv).pvalue) if np.any(diff_hv != 0) else 1.0}
        for k in SIZE_CAPS:
            d_k = d[f"size{k}_f1"].values - b.loc[d.fold, f"size{k}_f1"].values
            ok = ~np.isnan(d_k)
            out[a][f"size{k}_diff"] = float(np.nanmean(d_k))
            out[a][f"size{k}_p"] = float(wilcoxon(d_k[ok]).pvalue) if ok.sum() > 5 and np.any(d_k[ok] != 0) else np.nan
    return pd.DataFrame(out).T


def feature_frequency(runs: pd.DataFrame, top: int = 30) -> pd.DataFrame:
    c = Counter(f for fs in runs["_features"] for f in fs)
    n = len(runs)
    rows = [{"feature": f, "count": k, "share": k / n} for f, k in c.most_common(top)]
    return pd.DataFrame(rows)


def block_usage(runs: pd.DataFrame) -> pd.DataFrame:
    blocks = ["rna", "mirna", "meth", "cnv", "mut", "clin"]
    return pd.DataFrame({b: runs.groupby("algorithm")["_blocks"].apply(lambda s: np.mean([b in x for x in s]))
                         for b in blocks})


def convergence(runs: pd.DataFrame, grid=np.arange(0, 5001, 250)) -> pd.DataFrame:
    out = {}
    for a, d in runs.groupby("algorithm"):
        curves = []
        for c in d["_curve"]:
            c = np.asarray(c, float)
            if len(c) == 0:
                continue
            curves.append(np.interp(grid, c[:, 0], c[:, 1], left=np.nan))
        out[a] = np.nanmean(np.array(curves), axis=0)
    return pd.DataFrame(out, index=grid)


def sensitivity(all_runs: pd.DataFrame, base: pd.DataFrame) -> pd.DataFrame:
    """Tagged runs (ALG_tag) against the main runs of ALG, paired by run index."""
    rows = []
    b = base.set_index("fold")
    for tagged in sorted(a for a in all_runs.algorithm.unique() if "_" in a):
        alg = tagged.split("_")[0]
        t = all_runs[all_runs.algorithm == tagged].set_index("run").sort_index()
        m = all_runs[all_runs.algorithm == alg].set_index("run").loc[t.index]
        row = {"setting": tagged, "n": len(t)}
        for col in ("hv_test", "hv_inner", "sel_f1", "sel_size", "max_test_f1", "budget2_f1", "size10_f1", "size50_f1"):
            row[f"{col}_main"], row[f"{col}_sens"] = m[col].mean(), t[col].mean()
        row["p_hv_test"] = float(wilcoxon(t.hv_test, m.hv_test).pvalue)
        d = t.hv_test.values - b.loc[t.fold, "hv_test"].values
        row["hv_test_minus_baseline"], row["runs_above_baseline"] = d.mean(), int((d > 0).sum())
        row["minutes"] = t.minutes.mean()
        rows.append(row)
    return pd.DataFrame(rows)


def main(results: Path, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    all_runs = load_runs(results)
    runs = all_runs[~all_runs.algorithm.str.contains("_")].copy()
    base = load_baselines(results)
    sens = sensitivity(all_runs, base)
    sens.to_csv(out / "sensitivity.tsv", sep="\t", index=False)
    summ = summary_table(runs)
    stats = {m: statistics(runs, m) for m in ("hv_test", "hv_inner", "sel_f1")}
    comp = baseline_comparison(runs, base)
    runs.drop(columns=["_features", "_blocks", "_curve"]).to_csv(out / "runs.tsv", sep="\t", index=False)
    base.to_csv(out / "baselines.tsv", sep="\t", index=False)
    summ.to_csv(out / "summary.tsv", sep="\t")
    comp.to_csv(out / "vs_baseline.tsv", sep="\t")
    feature_frequency(runs).to_csv(out / "feature_frequency.tsv", sep="\t", index=False)
    block_usage(runs).to_csv(out / "block_usage.tsv", sep="\t")
    convergence(runs).to_csv(out / "convergence.tsv", sep="\t")
    json.dump(stats, open(out / "statistics.json", "w"), indent=1)
    extra = {}
    for method in METHODS[1:]:          # additional filter fronts, if they have been run
        b = load_baselines(results, method)
        if len(b) == len(base):
            b.to_csv(out / f"baselines_{method}.tsv", sep="\t", index=False)
            extra[method] = baseline_comparison(runs, b)
            extra[method].to_csv(out / f"vs_baseline_{method}.tsv", sep="\t")
    pd.set_option("display.width", 250)
    print(summ.round(3).to_string())
    print("\nbaseline per fold\n", base.round(3).to_string())
    print("\nvs baseline\n", comp.round(4).to_string())
    print("\nsensitivity\n", sens.round(4).T.to_string())
    for m, s in stats.items():
        print(f"\n{m}: best={s['best']} Friedman runs p={s['friedman_runs']['p']:.3g} folds p={s['friedman_folds']['p']:.3g}")
        print({k: round(v, 4) for k, v in s["wilcoxon_vs_best_holm"].items()})


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", type=Path, default=RESULTS_DIR)
    ap.add_argument("--out", type=Path, default=None)
    a = ap.parse_args()
    main(a.results, a.out or a.results / "summary")
