"""
TELSO: two-layer encoding learning swarm optimizer based on frequent itemsets.

S. Qi, R. Wang, T. Zhang, X. Yang, R. Sun, L. Wang, "A two-layer encoding
learning swarm optimizer based on frequent itemsets for sparse large-scale
multi-objective optimization", IEEE/CAA J. Autom. Sinica 11(6):1342-1357,
2024, DOI 10.1109/JAS.2024.124341.

Source followed
---------------
This is a line-by-line port of the PlatEMO 4.x MATLAB code (TELSO.m,
Operator.m, Initial_EnvironmentalSelection.m, EnvironmentalSelection.m,
written by the first author, Sheng Qi). The paper states that all its
experiments used "the source code proffered by PlatEMO", and the default
``variant="code"`` follows that code.

Where the code and the paper's text differ, the default follows the code:

* Initialization. Code and paper agree: SparseEA-style variable scoring with
  ``1 + 4*REAL`` rounds of D single-variable solutions (identity masks; real
  Dec uniform in the bounds, binary Dec all ones), DF = sum of
  non-dominated front numbers; initial masks by binary tournaments on DF;
  the N + (1+4*REAL)*D solutions are reduced to N by NSGA-II selection and
  then by the RVEA (APD) selection. This costs 5*D + N evaluations on a real
  problem (half of the 10*D budget used in the paper, consistent with the
  paper's Fig. 6 remark that TELSO's IGD only drops after ~5000 FEs).
* Mask learning (ML). Paper: assign *all* frequent items of the two better
  particles (both 1 with prob. 0.5, else both 0). Code: assign only the
  first ``floor(|F_i| * FE/maxFE)`` of them (in index order). Code followed.
* Mask mutation (MM, Algorithm 3 of the paper: flip one frequent or one
  infrequent bit depending on FE/maxFE versus a random number). Absent from
  the code. Not applied by default (``variant="paper"`` enables it).
* Velocity. Paper eq. (5) uses the particle's velocity vector V_i. The code
  writes ``PopulationVel(i)``, a MATLAB linear index into the N x D velocity
  matrix, i.e. the scalar V(i, 1) broadcast to all dimensions. Code followed.
* Teachers. Paper: two *distinct* better particles. Code:
  ``randi([i+1, N], 1, 2)``, which may draw the same particle twice. Code
  followed.
* Other code behaviours reproduced: the two best (by SDE fitness) particles
  are copied into the offspring and re-evaluated; the masks updated in the
  learning loop are also attached to the parents in the next environmental
  selection (``repmat(Mask, 2, 1)``); the population returned by RVEA's
  selection holds at most one solution per reference vector, so its size
  can fall below N; decision vectors are repaired as PROBLEM.CalDec does
  (clip to the bounds, round binary variables).

``variant="paper"`` implements the paper's text (full frequent-item
assignment, MM mutation, vector velocity, distinct teachers) with the same
initialization and environmental selection; it is kept for the record.

Budget handling (not in PlatEMO, which may overshoot maxFE in the last
generation): every batch is truncated to ``problem.remaining``. If the budget
is smaller than the variable-scoring stage needs (only possible on very
small budgets), the unevaluated variables get the worst DF and the run stops
after selecting N solutions among those evaluated.
"""

from __future__ import annotations

import bisect

import numpy as np

from mopoise.moeas.base import crowding_distance, nd_sort, tournament_selection, uniform_point


# --------------------------------------------------------------- helpers ---
def _nd_sort(F: np.ndarray, n_sort=np.inf):
    """PlatEMO NDSort. Exact O(N log N) first-fit algorithm for two objectives
    (memory-safe for the tens of thousands of solutions of the initialization);
    base.nd_sort otherwise."""
    F = np.asarray(F, float)
    if F.shape[1] != 2 or len(F) < 2000:
        return nd_sort(F, n_sort)
    N = len(F)
    order = np.lexsort((F[:, 1], F[:, 0]))        # by f1, then f2
    front = np.empty(N)
    last_f1: list[float] = []                      # last member of each front
    last_f2: list[float] = []                      # non-decreasing over the fronts
    for idx in order:
        f1, f2 = F[idx]
        # a front's last member L has L.f1 <= f1 and the smallest f2 of the front,
        # so the front dominates (f1, f2) iff L.f2 <= f2 and L is not a duplicate.
        k = bisect.bisect_left(last_f2, f2)
        kr = bisect.bisect_right(last_f2, f2)
        for j in range(k, kr):
            if last_f1[j] == f1:                   # exact duplicate of L_j
                k = j
                break
        else:
            k = kr
        if k == len(last_f2):
            last_f1.append(f1)
            last_f2.append(f2)
        else:
            last_f1[k], last_f2[k] = f1, f2
        front[idx] = k + 1
    if np.isfinite(n_sort):
        maxf = np.sort(front)[min(int(n_sort), N) - 1]
        front[front > maxf] = np.inf
        return front, maxf
    return front, front.max()


def _sde_fitness(F: np.ndarray) -> np.ndarray:
    """CalFitness of TELSO.m: shift-based density (larger is better)."""
    N = len(F)
    fmax, fmin = F.max(axis=0), F.min(axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        P = (F - fmin) / (fmax - fmin)
    # Dis(i, j) = ||P_i - max(P_j, P_i)|| = ||max(P_j - P_i, 0)||
    diff = np.maximum(P[None, :, :] - P[:, None, :], 0)
    diff = np.where(np.isnan(P[None, :, :] - P[:, None, :]), np.nan, diff)
    Dis = np.sqrt((diff ** 2).sum(axis=2))
    np.fill_diagonal(Dis, np.inf)
    with np.errstate(all="ignore"):
        allnan = np.isnan(Dis).all(axis=1)
        fit = np.where(allnan, np.nan, np.nanmin(np.where(np.isnan(Dis), np.inf, Dis), axis=1))
    return fit


def _initial_selection(F: np.ndarray, N: int) -> np.ndarray:
    """Initial_EnvironmentalSelection.m (NSGA-II selection). Returns selected indices (in order)."""
    front, max_f = _nd_sort(F, N)
    nxt = front < max_f
    cd = crowding_distance(F, front)
    last = np.flatnonzero(front == max_f)
    rank = np.argsort(-cd[last], kind="stable")
    nxt[last[rank[: N - nxt.sum()]]] = True
    return np.flatnonzero(nxt)


def _cos_angle(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    """acos(1 - pdist2(A, B, 'cosine')) with MATLAB's NaN for zero vectors."""
    na = np.linalg.norm(A, axis=1)[:, None]
    nb = np.linalg.norm(B, axis=1)[None, :]
    with np.errstate(divide="ignore", invalid="ignore"):
        c = (A @ B.T) / (na * nb)
    return np.arccos(np.clip(c, -1, 1))  # NaN stays NaN


def _nanargmin(x: np.ndarray) -> int:
    """MATLAB [~, i] = min(x): NaNs ignored, first index if all NaN."""
    if np.isnan(x).all():
        return 0
    return int(np.nanargmin(x))


def _apd_selection(F: np.ndarray, V: np.ndarray, theta: float) -> np.ndarray:
    """EnvironmentalSelection.m (RVEA's APD selection, unconstrained). Returns selected indices."""
    N, M = F.shape
    P = F - F.min(axis=0)
    cosine = np.clip(V @ V.T / np.outer(np.linalg.norm(V, axis=1), np.linalg.norm(V, axis=1)), -1, 1)
    np.fill_diagonal(cosine, 0)
    gamma = np.arccos(cosine).min(axis=1)
    angle = _cos_angle(P, V)
    assoc = np.array([_nanargmin(a) for a in angle])
    norms = np.sqrt((P ** 2).sum(axis=1))
    nxt = []
    for i in np.unique(assoc):
        cur = np.flatnonzero(assoc == i)
        apd = (1 + M * theta * angle[cur, i] / gamma[i]) * norms[cur]
        nxt.append(cur[_nanargmin(apd)])
    return np.array(nxt, int)


def _repair(problem, X: np.ndarray) -> np.ndarray:
    """PROBLEM.CalDec: clip to bounds, round binary variables."""
    X = np.minimum(np.maximum(X, problem.lower), problem.upper)
    if problem.encoding == "binary":
        X = np.floor(X + 0.5)        # MATLAB round (half away from zero; X >= 0 after clipping)
    return X


def _evaluate(problem, X: np.ndarray):
    X = _repair(problem, X)[: problem.remaining]
    return X, problem.evaluate(X) if len(X) else np.empty((0, problem.n_obj))


# ------------------------------------------------------------------ main ---
def run(problem, pop_size: int, rng: np.random.Generator, callback=None,
        variant: str = "code", chunk: int = 1000, **params):
    if variant not in ("code", "paper"):
        raise ValueError(variant)
    D, M = problem.n_var, problem.n_obj
    V = uniform_point(pop_size, M)
    N = len(V)
    real = problem.encoding != "binary"
    lo, up = problem.lower, problem.upper
    budget0 = problem.max_evals

    def frac():
        return problem.n_evals / budget0

    # ---- variable scoring (Dec .* eye(D)), 1 + 4*REAL rounds ----
    T_X, T_F = [], []
    DF = np.zeros(D)
    for _ in range(1 + 4 * real):
        Xr = np.empty((0, D))
        Fr = np.empty((0, M))
        for s in range(0, D, chunk):
            e = min(s + chunk, D)
            dec = rng.uniform(lo, up, size=(e - s, D)) if real else np.ones((e - s, D))
            mask = np.zeros((e - s, D))
            mask[np.arange(e - s), np.arange(s, e)] = 1
            x, f = _evaluate(problem, dec * mask)
            Xr, Fr = np.vstack([Xr, x]), np.vstack([Fr, f])
            if problem.exhausted:
                break
        if len(Fr):
            fr, _ = _nd_sort(Fr)
            dfr = np.full(D, fr.max() + 1.0)      # unevaluated variables (budget exhausted): worst
            dfr[: len(Fr)] = fr
            DF += dfr
            T_X.append(Xr)
            T_F.append(Fr)
        if problem.exhausted:
            break
    T_X, T_F = np.vstack(T_X), np.vstack(T_F)
    # TELSO.m keeps TMask = [eye(D); eye(D); ...] for these solutions
    T_mask = np.vstack([np.eye(D) for _ in range(int(np.ceil(len(T_X) / D)))])[: len(T_X)]

    # ---- initial population ----
    dec = rng.uniform(lo, up, size=(N, D)) if real else np.ones((N, D))
    mask = np.zeros((N, D))
    for i in range(N):
        mask[i, tournament_selection(2, int(np.ceil(rng.random() * D)), DF, rng=rng)] = 1
    X0, F0 = _evaluate(problem, dec * mask)
    mask = mask[: len(X0)]
    allX, allF, allM = np.vstack([X0, T_X]), np.vstack([F0, T_F]), np.vstack([mask, T_mask])
    sel = _initial_selection(allF, min(N, len(allF)))
    X, F, Mask = allX[sel], allF[sel], allM[sel]
    sel = _apd_selection(F, V, frac() ** 2)
    X, F, Mask = X[sel], F[sel], Mask[sel]
    Vel = np.zeros_like(X)

    # ---- optimization ----
    while not problem.exhausted:
        if callback is not None:
            callback(problem, X, F)
        order = np.argsort(_sde_fitness(F), kind="stable")
        X, F, Mask, Vel = X[order], F[order], Mask[order], Vel[order]
        OffX, OffVel, Mask = _operator(problem, X, Vel, Mask, frac(), rng, variant)
        OffX, OffF = _evaluate(problem, OffX)
        OffVel = OffVel[: len(OffX)]
        UX, UF = np.vstack([X, OffX]), np.vstack([F, OffF])
        UVel = np.vstack([Vel, OffVel])
        UMask = np.vstack([Mask, Mask])[: len(UX)]
        sel = _apd_selection(UF, V, frac() ** 2)
        X, F, Vel, Mask = UX[sel], UF[sel], UVel[sel], UMask[sel]
    if callback is not None:
        callback(problem, X, F)
    return X, F


def _operator(problem, X, Vel, Mask, t, rng, variant):
    """Operator.m. X, Vel, Mask are sorted by ascending SDE fitness (last = best)."""
    N, D = X.shape
    Mask = Mask.copy()
    OffDec = np.empty((N, D))
    OffVel = np.empty((N, D))
    for i in range(N - 2):
        if variant == "code":
            o = rng.integers(i + 1, N, size=2)              # randi([i+1, N], 1, 2), may repeat
        else:
            o = rng.choice(np.arange(i + 1, N), size=2, replace=False)
        r1, r2, r3 = rng.random(3)
        v_prev = Vel[i, 0] if variant == "code" else Vel[i]  # code: PopulationVel(i) = Vel(i, 1)
        vel = r1 * v_prev + r2 * (X[o[0]] - X[i]) + r3 * (X[o[1]] - X[i])
        OffDec[i] = X[i] + vel
        OffVel[i] = vel
        p1, p2 = Mask[o[0]], Mask[o[1]]
        if rng.random() < 0.5:
            same = np.flatnonzero((p1 == p2) & (p2 == 1))
        else:
            same = np.flatnonzero((p1 == p2) & (p2 == 0))
        if variant == "code":
            keep = int(np.floor(len(same) * t))
            same = same[:keep]
        Mask[i, same] = Mask[o[0], same]
        if variant == "paper":
            freq = np.flatnonzero(p1 == p2)
            pool = freq if t < rng.random() else np.setdiff1d(np.arange(D), freq)
            if len(pool):
                j = pool[rng.integers(len(pool))]
                Mask[i, j] = 1 - Mask[i, j]
    for i in range(max(N - 2, 0), N):                       # the two winners, re-evaluated
        OffDec[i] = X[i]
        OffVel[i] = Vel[i]
    return OffDec * Mask, OffVel, Mask
