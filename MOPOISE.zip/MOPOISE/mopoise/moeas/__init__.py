"""
Implementations of MOEAs first published in 2024 or later, ported from
the reference MATLAB code in PlatEMO 4.x (or from the paper when no code is
public).

Each algorithm module exposes ``run(problem, pop_size, rng, callback=None, **params)``
(see ``base.py``). ``REGISTRY`` maps the algorithm name to
``(module_name, kind)`` where ``kind`` says how the algorithm meets the
binary panel problem:

* "binary"  the algorithm supports binary decision variables natively and
            receives ``PanelBinaryProblem``;
* "real"    the algorithm is real-coded and receives ``PanelRealProblem``
            (variables in [0, 1], feature j selected iff x_j > 0.5).

Algorithms whose original design prescribes no problem-specific
initialization or variation (general-purpose MOEAs) use the panel problem's
``initial_population`` and ``variation``, which are the same block-sparse
sampling, uniform crossover and block-aware mutation given to the pymoo
algorithms (``mopoise.search``). Sparse-specific MOEAs keep their own
operators. On problems without these hooks every algorithm runs exactly as
in its reference implementation.
"""

from __future__ import annotations

import importlib

import numpy as np

from mopoise.moeas.base import BaseProblem

REGISTRY: dict[str, tuple[str, str]] = {}


def register(name: str, module: str, kind: str) -> None:
    REGISTRY[name] = (module, kind)


def get_run(name: str):
    module, kind = REGISTRY[name]
    return importlib.import_module(f"mopoise.moeas.{module}").run, kind


class PanelBinaryProblem(BaseProblem):
    """The three-objective panel problem for algorithms that operate on bit vectors.

    An empty mask gets the worst point (error 1, full assay cost, size 1), so
    it is dominated by every non-empty panel; this replaces the repair used
    for the pymoo algorithms without touching the algorithms' own operators.
    """
    encoding = "binary"

    def __init__(self, evaluator, max_evals: int):
        super().__init__(evaluator.n_features, 3, 0.0, 1.0, max_evals)
        self.evaluator = evaluator
        self.block_slices = evaluator.block_slices
        self.worst = np.array([1.0, evaluator.total_cost, 1.0])

    def masks(self, X: np.ndarray) -> np.ndarray:
        return np.asarray(X, dtype=bool)

    # shared operators (same as for the pymoo algorithms) -------------------
    def initial_population(self, n: int, rng: np.random.Generator) -> np.ndarray:
        from mopoise.search import BlockSparseSampling
        density = getattr(self, "density", (0.005, 0.2))
        return BlockSparseSampling(self.block_slices, density=density)._do(self, n, random_state=rng)

    def variation(self, P1: np.ndarray, P2: np.ndarray, rng: np.random.Generator) -> np.ndarray:
        """Two offspring per parent pair: uniform crossover (prob 0.9) then block-aware mutation."""
        from mopoise.search import BlockAwareMutation
        P1, P2 = np.asarray(P1, bool), np.asarray(P2, bool)
        swap = rng.random(P1.shape) < 0.5
        swap[rng.random(len(P1)) >= 0.9] = False
        O1, O2 = P1.copy(), P2.copy()
        O1[swap], O2[swap] = P2[swap], P1[swap]
        return BlockAwareMutation(self.block_slices)._do(self, np.vstack([O1, O2]), random_state=rng)

    def _evaluate(self, X):
        M = self.masks(X)
        return np.array([self.evaluator.objectives(m) if m.any() else self.worst for m in M])


class PanelRealProblem(PanelBinaryProblem):
    encoding = "real"

    def initial_population(self, n: int, rng: np.random.Generator) -> np.ndarray:
        """Block-sparse masks mapped to [0, 1]: selected bits in (0.5, 1], others in [0, 0.5)."""
        B = super().initial_population(n, rng)
        return np.where(B, 0.5 + 0.5 * rng.random(B.shape) + 1e-9, 0.5 * rng.random(B.shape)).clip(0, 1)

    def masks(self, X: np.ndarray) -> np.ndarray:
        return np.asarray(X, dtype=float) > 0.5


register("NRVMOEA", "nrvmoea", "binary")
register("MOBCA", "mobca", "real")
register("TELSO", "telso", "binary")
register("IMCMOEAD", "imcmoead", "real")
