"""
IM-C-MOEA/D: Inverse Modeling Constrained Multi-Objective Evolutionary
Algorithm Based on Decomposition.

L. R. C. Farias and A. F. R. Araujo, "An inverse modeling constrained
multi-objective evolutionary algorithm based on decomposition", Proc. IEEE
International Conference on Systems, Man, and Cybernetics (SMC 2024),
pp. 3624-3629, doi:10.1109/SMC54092.2024.10831275; open-access preprint
arXiv:2410.19203 (24 Oct 2024).

Port of PlatEMO 4.x ``Algorithms/Multi-objective optimization/IM-C-MOEA-D``
(IMCMOEAD.m, Operator.m, applyConstraintHandling.m, globalReplacement.m,
and the bundled gpml-matlab-v3.4 functions gp/infExact/covLIN/meanZero/
likGauss that Operator.m calls).

Main loop (IMCMOEAD.m)::

    T = ceil(N/10);  [W,N] = UniformPoint(N,M);  B = T nearest weight vectors
    Population = Initialization();  z = min(Population.objs)
    while NotTerminated(Population)
        partition = kmeans(Population.objs, K)                  # K = 10
        for each cluster k:
            MatingPool = TournamentSelection(2, |k|, CV)         # binary, on CV
            Offspring += Operator(parents(MatingPool))           # inverse GP model
        PopObj, OffObj = applyConstraintHandling(...)            # penalised objs
        z = min(z, OffObj);  znad = max([PopObj; OffObj])
        normalise PopObj, OffObj with (z, znad)
        Population = globalReplacement(...)                      # Tchebycheff

Operator.m (inverse modelling): if the mating pool has fewer than 2M members
the parents are copied; otherwise, for every objective m, floor(n/M) random
parents are copied and L = 3 random decision variables are re-sampled from
a Gaussian process x_d | f_m (linear covariance ``covLIN``, zero mean,
Gaussian likelihood with sigma_n = 0.01, no hyper-parameter fitting) at
n/M equally spaced values of f_m in [1.5 min - 0.5 max, 1.5 max - 0.5 min]:
x_d = mu + rand * sqrt(s2) .* randn. Out-of-bound values are re-drawn
uniformly, then polynomial mutation (proM = 1, disM = 20) is applied.

globalReplacement.m: each offspring finds the weight vector with the
smallest Tchebycheff value of its normalised (penalised) objectives and
replaces every solution in that vector's neighbourhood whose Tchebycheff
value is >= the offspring's and whose total constraint violation is >= the
offspring's.

Constraints: if the problem object has ``evaluate_constrained(X) -> (F, G)``
(G <= 0 feasible, PlatEMO convention), constraint values are used exactly
as in the MATLAB code; otherwise all constraint values are zero (the
unconstrained / panel case), and then applyConstraintHandling is the
identity and the tournament is uniform random.

Deviations from the MATLAB code (unavoidable or distribution-preserving):

* Random numbers come from numpy's ``Generator``; the stream differs from
  MATLAB's.
* ``kmeans``: MATLAB's default (k-means++ seeding, one replicate, batch
  Lloyd iterations up to 100, empty clusters replaced by the singleton point
  farthest from its centroid) is implemented in numpy. MATLAB's optional
  online-update phase is off by default and is not used.
* The gpml prediction is computed with the same formulas as gp.m/infExact.m
  (Cholesky of K/sn2 + I, alpha, V = L' \\ (sW .* Ks), fs2 = kss - sum(V.^2),
  clipped at 0, ys2 = fs2 + sn2). Numerical failures (non-finite input or a
  failed Cholesky) leave the variable unchanged, as the MATLAB ``try/catch``.
* TournamentSelection follows PlatEMO exactly (tied fitness gets the same
  rank and the first-drawn candidate wins), not ``base.tournament_selection``
  (which breaks ties by index and would bias the CV = 0 case toward low
  indices).
* MATLAB evaluates each cluster's offspring inside Operator.m; here the
  offspring decision vectors of all clusters are generated first and then
  evaluated in one batch. The random draws do not depend on evaluations, so
  this is equivalent, except that when the evaluation budget would be
  exceeded the batch is truncated to ``problem.remaining`` (PlatEMO
  evaluates the whole last generation and overshoots maxFE slightly).
* globalReplacement.m indexes ``find(tchebycheff_values == min)``; if all
  values are NaN (degenerate normalisation, nadir == ideal), MATLAB would
  raise an error. Here such an offspring is skipped. The stale ``PopObj``
  quirk of the MATLAB code (the normalised objectives of replaced solutions
  are not updated during the replacement loop, while their constraint
  violations are) is reproduced on purpose.
* If the problem object provides ``initial_population(n, rng)`` (the panel
  application, PanelRealProblem), it replaces PlatEMO's uniform
  ``Problem.Initialization``. Benchmarks use uniform initialization. The
  reproduction operator is the algorithm's own inverse model and is not
  replaced by the problem's ``variation`` (IM-C-MOEA/D is real-coded only).
"""

from __future__ import annotations

from math import ceil

import numpy as np

from mopoise.moeas.base import polynomial_mutation, uniform_point


# ----------------------------------------------------------- evaluation ---
def _evaluate(problem, X):
    if hasattr(problem, "evaluate_constrained"):
        F, G = problem.evaluate_constrained(X)
        G = np.asarray(G, float).reshape(len(X), -1)
    else:
        F = problem.evaluate(X)
        G = np.zeros((len(X), 1))
    return np.asarray(F, float), G


# ----------------------------------------------------- PlatEMO utilities ---
def _tournament(K: int, N: int, fitness: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """PlatEMO TournamentSelection.m (single fitness column): ties share a rank,
    the first-drawn candidate wins a tie."""
    f = np.asarray(fitness, float).ravel()
    _, loc = np.unique(f, return_inverse=True)   # rank of unique value (sorted)
    loc = loc.ravel()
    parents = rng.integers(0, len(f), size=(K, N))
    best = np.argmin(loc[parents], axis=0)       # first minimum -> first drawn
    return parents[best, np.arange(N)]


def _kmeans(X: np.ndarray, K: int, rng: np.random.Generator, max_iter: int = 100) -> np.ndarray:
    """MATLAB kmeans(X,K) defaults: k-means++ ('plus') start, sqeuclidean,
    batch updates, EmptyAction 'singleton'. Returns 0-based labels."""
    n = len(X)
    if n <= K:
        return np.arange(n)
    C = np.empty((K, X.shape[1]))
    C[0] = X[rng.integers(n)]
    d2 = ((X - C[0]) ** 2).sum(axis=1)
    for j in range(1, K):
        s = d2.sum()
        if not np.isfinite(s) or s <= 0:
            idx = rng.integers(n)
        else:
            idx = int(np.searchsorted(np.cumsum(d2) / s, rng.random(), side="right"))
            idx = min(idx, n - 1)
        C[j] = X[idx]
        d2 = np.minimum(d2, ((X - C[j]) ** 2).sum(axis=1))
    labels = None
    for _ in range(max_iter):
        D = ((X[:, None, :] - C[None, :, :]) ** 2).sum(axis=2)
        new = np.argmin(D, axis=1)
        # empty clusters -> singleton: the point farthest from its centroid
        for j in range(K):
            if not np.any(new == j):
                dist = D[np.arange(n), new]
                far = int(np.argmax(dist))
                new[far] = j
        if labels is not None and np.array_equal(new, labels):
            break
        labels = new
        for j in range(K):
            C[j] = X[labels == j].mean(axis=0)
    return labels


def _gp_predict(x: np.ndarray, y: np.ndarray, xs: np.ndarray, sn2: float = 1e-4):
    """gpml v3.4 gp(hyp, @infExact, @meanZero, @covLIN, @likGauss, x, y, xs)
    with hyp.lik = log(0.01); returns (ymu, ys2). Raises on failure."""
    if not (np.all(np.isfinite(x)) and np.all(np.isfinite(y)) and np.all(np.isfinite(xs))):
        raise np.linalg.LinAlgError("non-finite input")
    n = len(x)
    Kxx = np.outer(x, x)
    # sn2 = 1e-4 >= 1e-6 branch of infExact: L = chol(K/sn2 + I), sl = sn2
    Lc = np.linalg.cholesky(Kxx / sn2 + np.eye(n))          # lower; MATLAB L = Lc'
    alpha = np.linalg.solve(Lc.T, np.linalg.solve(Lc, y)) / sn2
    Ks = np.outer(x, xs)                                     # n x ns
    fmu = Ks.T @ alpha
    sW = 1.0 / np.sqrt(sn2)
    V = np.linalg.solve(Lc, sW * Ks)                         # L' \ (sW .* Ks)
    kss = xs * xs
    fs2 = np.maximum(kss - (V * V).sum(axis=0), 0.0)
    if not (np.all(np.isfinite(fmu)) and np.all(np.isfinite(fs2))):
        raise np.linalg.LinAlgError("non-finite prediction")
    return fmu, fs2 + sn2


def _operator(PopDec, PopObj, lower, upper, M, rng, L=3):
    """Operator.m (decision vectors only; evaluation by the caller)."""
    N, D = PopDec.shape
    if D < 3:
        L = D
    if N < 2 * M:
        OffDec = PopDec.copy()
    else:
        parts = []
        fmin = 1.5 * PopObj.min(axis=0) - 0.5 * PopObj.max(axis=0)
        fmax = 1.5 * PopObj.max(axis=0) - 0.5 * PopObj.min(axis=0)
        for m in range(M):
            par = rng.permutation(N)[: N // M]
            offDec = PopDec[par].copy()
            for d in rng.permutation(D)[:L]:
                try:
                    ymu, ys2 = _gp_predict(PopObj[par, m], PopDec[par, d],
                                           np.linspace(fmin[m], fmax[m], len(offDec)))
                    offDec[:, d] = ymu + rng.random() * np.sqrt(ys2) * rng.standard_normal(len(ys2))
                except np.linalg.LinAlgError:
                    pass
            parts.append(offDec)
        OffDec = np.vstack(parts)
    n = len(OffDec)
    Lo, Up = np.broadcast_to(lower, (n, D)), np.broadcast_to(upper, (n, D))
    rand_dec = rng.uniform(Lo, Up)
    with np.errstate(invalid="ignore"):
        invalid = (OffDec < Lo) | (OffDec > Up)
    OffDec[invalid] = rand_dec[invalid]
    return polynomial_mutation(OffDec, lower, upper, rng, 1.0, 20.0)


def _constraint_handling(F, G, M):
    """applyConstraintHandling.m"""
    PopObj = F.copy()
    PopCon = np.maximum(0, G)
    infeasible = (PopCon > 0).any(axis=1)
    if infeasible.any():
        PopObj[infeasible] = F.max(axis=0)[None, :] + PopCon[infeasible].sum(axis=1)[:, None]
    return PopObj


def _global_replacement(PX, PF, PG, OX, OF, OG, W, B, T, PopObj, OffObj, rng):
    """globalReplacement.m (PopObj is deliberately not updated in the loop)."""
    PX, PF, PG = PX.copy(), PF.copy(), PG.copy()
    for i in range(len(OX)):
        with np.errstate(invalid="ignore"):
            tch = (OffObj[i][None, :] * W).max(axis=1)
        if np.all(np.isnan(tch)):
            continue
        bw = int(np.flatnonzero(tch == np.nanmin(tch))[0])   # MATLAB min ignores NaN; find(...)(1)
        P = B[bw, rng.permutation(B.shape[1])]
        CVO = np.maximum(0, OG[i]).sum()
        CVP = np.maximum(0, PG[P]).sum(axis=1)
        with np.errstate(invalid="ignore"):
            g_old = (PopObj[P] * W[P]).max(axis=1)
            g_new = (OffObj[i][None, :] * W[P]).max(axis=1)
            hit = P[(g_old >= g_new) & (CVP >= CVO)][:T]
        PX[hit], PF[hit], PG[hit] = OX[i], OF[i], OG[i]
    return PX, PF, PG


# ------------------------------------------------------------------ run ---
def run(problem, pop_size: int, rng: np.random.Generator, callback=None, K: int = 10, L: int = 3,
        return_constraints: bool = False):
    M = problem.n_obj
    T = int(ceil(pop_size / 10))
    W = uniform_point(pop_size, M)
    N = len(W)
    dist = np.sqrt(((W[:, None, :] - W[None, :, :]) ** 2).sum(axis=2))
    B = np.argsort(dist, axis=1, kind="stable")[:, :T]

    if hasattr(problem, "initial_population"):
        PX = np.asarray(problem.initial_population(N, rng), float)
    else:
        PX = rng.uniform(problem.lower, problem.upper, size=(N, problem.n_var))
    PX = PX[: problem.remaining]
    PF, PG = _evaluate(problem, PX)
    ideal = PF.min(axis=0)

    while True:
        if callback is not None:
            callback(problem, PX, PF)
        if problem.exhausted:
            break
        partition = _kmeans(PF, K, rng)
        CV = np.maximum(0, PG).sum(axis=1)
        off = []
        for k in np.unique(partition):
            idx = np.flatnonzero(partition == k)
            pool = idx[_tournament(2, len(idx), CV[idx], rng)]
            off.append(_operator(PX[pool], PF[pool], problem.lower, problem.upper, M, rng, L))
        OX = np.vstack(off)[: problem.remaining]
        OF, OG = _evaluate(problem, OX)
        if PG.shape[1] != OG.shape[1]:
            raise RuntimeError("inconsistent constraint dimensions")

        PopObj = _constraint_handling(PF, PG, M)
        OffObj = _constraint_handling(OF, OG, M)
        ideal = np.minimum(ideal, OffObj.min(axis=0))
        nadir = np.vstack([PopObj, OffObj]).max(axis=0)
        with np.errstate(divide="ignore", invalid="ignore"):
            PopObj = (PopObj - ideal) / (nadir - ideal)
            OffObj = (OffObj - ideal) / (nadir - ideal)
        PX, PF, PG = _global_replacement(PX, PF, PG, OX, OF, OG, W, B, T, PopObj, OffObj, rng)

    if return_constraints:
        return PX, PF, PG
    return PX, PF
