"""
NRV-MOEA: adaptive normal reference vector-based multi- and many-objective
evolutionary algorithm.

Y. Hua, Q. Liu, K. Hao, "Adaptive normal vector guided evolutionary multi- and
many-objective optimization", Complex & Intelligent Systems 10:3709-3726
(2024), DOI 10.1007/s40747-024-01353-y.

Line-by-line port of PlatEMO 4.x ``Algorithms/Multi-objective optimization/
NRV-MOEA`` (NRVMOEA.m, UpdateArchive.m, vertmap.m). Per generation:

1. Arc <- UpdateArchive(P, Arc, N) (non-dominated, epsilon-indicator truncation
   to N, removal of points farther than 10x the mean distance to the ideal);
2. P <- P u Arc; N parents drawn uniformly at random (randi) from P; OperatorGA
   (SBX + PM on real problems) gives 2*floor(N/2) offspring;
3. U = P u Q is non-dominated sorted (NDSort(.,N)); fronts before the last
   accepted front F_l are kept; the points of F_l (padded with random kept
   points up to 10 if |F_l| < M) are normalised with (Zmin, scale), projected
   onto the hyperplane through the archive's extreme points along the plane's
   normal (vertmap), and clustered into N - |kept| clusters by Ward
   hierarchical clustering; from each cluster the point minimising
   ||map - centroid|| - (distance of the point below the hyperplane) is chosen;
4. if the result has more than N individuals, or FE >= 0.9*maxFE, it is
   reduced to its first fronts (NDSort(.,N)), the M per-objective minimum
   points are protected and the most crowded of the others are deleted one
   by one until N of them remain (the population then has N + M members,
   exactly as in the MATLAB code).

``scale`` is only refreshed when ``mod(FE, ceil(0.1*maxFE)) == 0``, as in the
MATLAB code (with N = 65 and 64 offspring per generation this never happens
on the 10-objective instances, so the scale of the initial population is kept
for the whole run; this is reproduced, not changed).

Individuals are identified as in MATLAB, where SOLUTION objects are handles:
``Population = [Population Archive]`` contains the same individual twice and
``unique(EP)`` removes those copies (but not distinct individuals with equal
objectives). Here every individual carries an integer id and ``unique``
works on the ids; the resulting order is by id (creation order) whereas
MATLAB sorts handle objects by an internal order. Order only matters for ties.

Deviations from the MATLAB code (unavoidable or behaviour-neutral):

* ``updateNadirPoint`` is not called: its outputs (Znadir, extremPoint) are
  only fed back into itself and are never used by the selection, so the call
  is dead code (it has no random draws either).
* ``Hyperplane_bp`` is never used by ``vertmap`` (the argument is ignored), so
  it is not carried around.
* Ward clustering uses ``scipy.cluster.hierarchy.linkage(.., 'ward')`` (same
  Lance-Williams/Ward distance as MATLAB's linkage 'ward'); the tree is cut
  into exactly K clusters by merge order, as MATLAB's ``cluster(Z,
  'maxclust', K)`` does (scipy's ``fcluster`` cuts by height and can return
  fewer clusters on ties). Merge order may differ from MATLAB on exact ties.
* The last batch of offspring is truncated to the remaining evaluation budget
  (PlatEMO evaluates the whole batch and slightly overshoots maxFE).
* MATLAB's ``max``/``min`` ignore NaN; the epsilon-indicator archive
  truncation uses NaN-ignoring reductions accordingly (NaN appears only if an
  objective is constant over the archive).
* Floating-point overflow (seen on DTLZ4, where an objective can collapse to
  ~1e-200 so that the fixed ``scale`` is tiny and the hyperplane coefficients
  huge): ``mapPop`` then becomes NaN exactly as in MATLAB and the code falls
  back to clustering ``PopObjn`` (the MATLAB try/catch; we assume MATLAB's
  clusterdata raises on NaN input, which is what that catch exists for). If
  ``PopObjn`` is finite but so large that pairwise distances overflow, it is
  divided by its largest absolute value before the Ward linkage (Ward merge
  order is invariant to a global rescaling; scipy refuses infinite distances
  where MATLAB would carry on). NaN distances/scores are skipped in argmin as
  MATLAB's ``min`` does.
* The extreme-point search of the final pruning step is bounded by the number
  of rows (MATLAB would raise an index error if fewer than M individuals were
  left; this cannot happen on the benchmarks).
* Random numbers come from numpy, so runs are not bit-identical to MATLAB.

Application mode: if the problem provides ``initial_population(n, rng)`` and
``variation(P1, P2, rng)``, they replace random initialisation and OperatorGA;
everything else (mating from P u Arc, environmental selection, archive) is
unchanged.
"""

from __future__ import annotations

import math

import numpy as np
from scipy.cluster.hierarchy import linkage

from mopoise.moeas.base import nd_sort, operator_ga


# ------------------------------------------------------------- helpers ---
class _Set:
    """A list of individuals: decision vectors, objectives and identities."""

    __slots__ = ("X", "F", "ids")

    def __init__(self, X, F, ids):
        self.X, self.F, self.ids = X, np.asarray(F, float), np.asarray(ids, np.int64)

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, idx):
        idx = np.asarray(idx, dtype=np.int64) if not isinstance(idx, slice) else idx
        return _Set(self.X[idx], self.F[idx], self.ids[idx])

    @staticmethod
    def cat(*sets):
        sets = [s for s in sets if s is not None and len(s)]
        return _Set(np.concatenate([s.X for s in sets]), np.concatenate([s.F for s in sets]),
                    np.concatenate([s.ids for s in sets]))


def _nanargmin(v):
    """MATLAB [~,i] = min(v): NaN ignored, first index if all NaN."""
    if np.all(np.isnan(v)):
        return 0
    return int(np.nanargmin(v))


def update_archive(pop: _Set, arc: _Set | None, max_size: int) -> _Set:
    """UpdateArchive.m."""
    A = _Set.cat(arc, pop) if arc is not None else pop
    _, ia = np.unique(A.F, axis=0, return_index=True)       # sorted rows, first occurrence
    A = A[ia]
    front, _ = nd_sort(A.F, 1)
    A = A[np.flatnonzero(front == 1)]
    n = len(A)
    if n <= max_size:
        return A
    # epsilon-indicator based fitness
    with np.errstate(divide="ignore", invalid="ignore"):
        fmin, fmax = A.F.min(0), A.F.max(0)
        CA = (A.F - fmin) / (fmax - fmin)
        diff = CA[:, None, :] - CA[None, :, :]
        I = np.where(np.all(np.isnan(diff), axis=2), np.nan, np.nanmax(np.where(np.isnan(diff), -np.inf, diff), axis=2))
        absI = np.abs(I)
        C = np.where(np.all(np.isnan(absI), axis=0), np.nan,
                     np.max(np.where(np.isnan(absI), -np.inf, absI), axis=0))
        Fit = np.sum(-np.exp(-I / C[None, :] / 0.05), axis=0) + 1
        choose = list(range(n))
        while len(choose) > max_size:
            x = _nanargmin(Fit[choose])
            cx = choose[x]
            Fit = Fit + np.exp(-I[cx, :] / C[cx] / 0.05)
            del choose[x]
    A = A[np.array(choose)]
    # delete those which are too far from the archive
    o = A.F - A.F.min(0)
    d = np.sqrt((o ** 2).sum(1))
    meanD = d.sum() / len(o)
    return A[np.flatnonzero(~(d > 10 * meanD))]


def vertmap(ArcObj: np.ndarray, PopObj: np.ndarray):
    """vertmap.m: project PopObj onto the hyperplane through the archive's extreme points."""
    N, M = PopObj.shape
    rank = np.argsort(-ArcObj, axis=0, kind="stable")          # sort(.., 'descend'), stable
    nr = rank.shape[0]
    extreme = np.zeros(M, dtype=np.int64)
    extreme[0] = rank[0, 0]
    for j in range(1, M):
        k = 0
        extreme[j] = rank[k, j]
        while extreme[j] in extreme[:j] and k < nr - 1:
            k += 1
            extreme[j] = rank[k, j]
    try:
        A = ArcObj[extreme] if ArcObj.shape[0] >= M else PopObj[extreme]
        with np.errstate(all="ignore"):
            H = np.linalg.solve(A, np.ones(M))
    except (np.linalg.LinAlgError, IndexError):
        H = np.ones(M)
    if np.isinf(H).any() or np.isnan(H).any():
        H = np.ones(M)
    t1 = PopObj @ H - 1
    t2 = np.sum(H ** 2)
    mapPop = (-H[None, :] * (t1[:, None] - H[None, :] * PopObj) + PopObj * (t2 - H[None, :] ** 2)) / t2
    return mapPop, H


def ward_maxclust(Xc: np.ndarray, K: int) -> np.ndarray:
    """clusterdata(X,'maxclust',K,'distance','euclidean','linkage','ward') -> labels 0..K-1."""
    n = len(Xc)
    if n <= K:
        return np.arange(n)
    if K == 1:
        return np.zeros(n, dtype=np.int64)
    if not np.all(np.isfinite(Xc)):
        raise ValueError("non-finite data")
    big = np.abs(Xc).max()
    if big > 1e150:
        # Ward merge order is invariant to a global rescaling; rescale only to keep
        # the pairwise distances from overflowing (scipy rejects infinite distances)
        Xc = Xc / big
    Z = linkage(Xc, method="ward", metric="euclidean")
    parent = np.arange(2 * n - 1)

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for k in range(n - K):                 # first n-K merges -> K clusters (MATLAB clusternum)
        a, b = int(Z[k, 0]), int(Z[k, 1])
        parent[find(a)] = n + k
        parent[find(b)] = n + k
    roots = np.array([find(i) for i in range(n)])
    _, labels = np.unique(roots, return_inverse=True)
    return labels


def _offspring(problem, parents: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    h = len(parents) // 2
    P1, P2 = parents[:h], parents[h:2 * h]
    if hasattr(problem, "variation"):
        return np.asarray(problem.variation(P1, P2, rng))
    return operator_ga(problem, P1, P2, rng)


def _initial(problem, n: int, rng: np.random.Generator) -> np.ndarray:
    if hasattr(problem, "initial_population"):
        return np.asarray(problem.initial_population(n, rng))
    if problem.encoding == "binary":
        return rng.random((n, problem.n_var)) < 0.5
    return problem.lower + rng.random((n, problem.n_var)) * (problem.upper - problem.lower)


# ----------------------------------------------------------------- main ---
def run(problem, pop_size: int, rng: np.random.Generator, callback=None, **params):
    N, M = int(pop_size), problem.n_obj
    max_fe = problem.max_evals
    refresh = math.ceil(0.1 * max_fe)
    next_id = 0

    def new_set(X):
        nonlocal next_id
        F = problem.evaluate(X)
        ids = np.arange(next_id, next_id + len(X))
        next_id += len(X)
        return _Set(X, F, ids)

    # ---- initialisation
    X0 = _initial(problem, N, rng)[: problem.remaining]
    pop = new_set(X0)
    Zmin = pop.F.min(0)
    Zmax = pop.F.max(0)
    scale = Zmax - Zmin
    arc = update_archive(pop, None, N)

    # ---- optimisation
    while True:
        if callback is not None:
            callback(problem, pop.X, pop.F)
        if problem.exhausted:
            break
        arc = update_archive(pop, arc, N)
        P = _Set.cat(pop, arc)
        mating = rng.integers(0, len(P), N)
        Xo = _offspring(problem, P.X[mating], rng)[: problem.remaining]
        off = new_set(Xo)
        U = _Set.cat(P, off)

        front, max_f = nd_sort(U.F, N)
        pareto = np.flatnonzero(front == max_f)
        chosen = np.flatnonzero(front < max_f)
        idp = chosen[rng.permutation(len(chosen))]
        if len(pareto) < M:
            pareto = np.concatenate([pareto, idp[: max(0, 10 - len(pareto))]])
        PopObj = U.F[pareto]
        Zmin = U.F.min(0)
        Zmax = PopObj.max(0)
        Zmin = np.minimum(Zmin, PopObj.min(0))
        # updateNadirPoint(...) omitted: its outputs are never used (dead code)
        if problem.n_evals % refresh == 0:
            scale = Zmax - Zmin
            scale = np.where(scale == 0, 1e-5, scale)
        scale = np.where(scale == 0, 1e-5, scale)
        with np.errstate(all="ignore"):
            PopObjn = (PopObj - Zmin) / scale
            ArcObjn = (arc.F - Zmin) / scale
            mapPop, H = vertmap(ArcObjn, PopObjn)
        K = N - len(chosen)
        try:
            T = ward_maxclust(mapPop, K)
        except ValueError:
            T = ward_maxclust(PopObjn, K)
        with np.errstate(all="ignore"):
            normH = np.sqrt(np.sum(H ** 2))
        picked = []
        for c in range(K):
            current = np.flatnonzero(T == c)
            pn = len(current)
            if pn == 0:
                continue
            if pn > 1:
                with np.errstate(all="ignore"):
                    Ref = mapPop[current].sum(0) / pn
                    d1 = np.sqrt(((Ref - mapPop[current]) ** 2).sum(1))
                    d2 = -(PopObjn[current] @ H - 1) / normH
                choose = current[_nanargmin(d1 - d2)]       # MATLAB min ignores NaN
            else:
                choose = current[0]
            picked.append(pareto[choose])
        cand = np.concatenate([np.array(picked, dtype=np.int64), chosen])
        _, first = np.unique(U.ids[cand], return_index=True)   # unique by identity, sorted by id
        EP = U[cand[first]]

        if len(EP) > N or problem.n_evals >= 0.9 * max_fe:
            fr, mf = nd_sort(EP.F, N)
            EP = EP[np.flatnonzero(fr <= mf)]
            rank = np.argsort(EP.F, axis=0, kind="stable")
            nr = rank.shape[0]
            extreme = np.zeros(M, dtype=np.int64)
            extreme[0] = rank[0, 0]
            for j in range(1, M):
                k = 0
                extreme[j] = rank[k, j]
                while extreme[j] in extreme[:j] and k < nr - 1:
                    k += 1
                    extreme[j] = rank[k, j]
            extreme_u = np.unique(extreme)
            EPtemp = EP[extreme] if len(extreme_u) == M else EP[extreme_u]
            rest = EP[np.setdiff1d(np.arange(len(EP)), extreme_u)]
            n_del = len(rest) - N
            if n_del > 0:
                with np.errstate(all="ignore"):
                    Fn = (rest.F - Zmin) / scale
                    D = np.sqrt(((Fn[:, None, :] - Fn[None, :, :]) ** 2).sum(2))
                np.fill_diagonal(D, 1e10)
                alive = np.arange(len(rest))
                for _ in range(n_del):
                    sub = D[np.ix_(alive, alive)]
                    with np.errstate(all="ignore"):
                        mind = np.where(np.isnan(sub), np.inf, sub).min(1)
                        mind[np.all(np.isnan(sub), axis=1)] = np.nan
                    dele = _nanargmin(mind)
                    alive = np.delete(alive, dele)
                rest = rest[alive]
            EP = _Set.cat(rest, EPtemp)
        pop = EP

    return pop.X, pop.F
