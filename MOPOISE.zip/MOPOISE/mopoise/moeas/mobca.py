"""
MOBCA: Multi-Objective Besiege and Conquer Algorithm.

J. Jiang, J. Wu, J. Luo, X. Yang, Z. Huang, "MOBCA: Multi-Objective Besiege
and Conquer Algorithm", Biomimetics 9(6):316, 2024, doi:10.3390/biomimetics9060316.

Port of PlatEMO 4.x ``Algorithms/Multi-objective optimization/MOBCA``
(MOBCA.m, OperatorBCAGrid.m, REPSelection.m, UpdateArchive.m,
BCAUpdatePop.m) and ``Utility functions/RouletteWheelSelection.m``.

Main loop (MOBCA.m)::

    nArmies    = fix(N / nSoldiers)
    Population = Initialization(nArmies);  Archive = Population
    while NotTerminated(Archive)
        REP        = REPSelection(Archive.objs, nArmies, div)      # grid roulette leaders
        Offspring  = OperatorBCAGrid(Population, BCB, Archive(REP), nSoldiers, nArmies)
        Archive    = UpdateArchive([Archive, Offspring], N, div)  # ND + grid deletion
        Population = BCAUpdatePop(Archive, Population, nArmies, div)

The reported population (what ``NotTerminated`` receives, and what this
``run`` returns and passes to ``callback``) is the **archive** (at most
``pop_size`` non-dominated solutions).

Parameters (PlatEMO defaults): BCB = 0.2, nSoldiers = 3, div = 10.

Deviations from the MATLAB code (unavoidable or distribution-preserving):

* Random numbers come from numpy's ``Generator``; the stream differs from
  MATLAB's, and OperatorBCAGrid draws its per-variable ``rand < BCB`` and the
  angle per (soldier, variable) in vectorised form. The draws are
  independent uniforms exactly as in the MATLAB loop, so the distribution of
  offspring is identical; only the order of consumption differs.
* Evaluation budget: PlatEMO evaluates whole generations and stops after
  the one that reaches maxFE (e.g. with N = 100: 33 + 101*99 = 10,032 FEs for
  maxFE = 10,000). Here the evaluator refuses to exceed ``max_evals``, so the
  last generation's offspring batch is truncated to ``problem.remaining``
  (the first soldiers in army order are kept; e.g. 67 of 99 on the ZDT runs).
* If the problem object provides ``initial_population(n, rng)`` (the panel
  application), it replaces PlatEMO's uniform ``Problem.Initialization`` for
  the ``nArmies`` initial armies. Benchmarks have no such method and use
  uniform initialization, as the reference.
* PlatEMO's ``Problem.CalDec`` repair is a no-op for real variables beyond
  the bound clipping that OperatorBCAGrid already does, so it is omitted.
"""

from __future__ import annotations

import numpy as np

from mopoise.moeas.base import nd_sort


# ---------------------------------------------------------------- grid ---
def _grid_sites(F: np.ndarray, div: int) -> np.ndarray:
    """Grid location of each solution -> 0-based index of its grid among the
    lexicographically sorted unique grid rows (MATLAB ``[~,~,Site] = unique(GLoc,'rows')``)."""
    fmax, fmin = F.max(axis=0), F.min(axis=0)
    d = (fmax - fmin) / div
    with np.errstate(divide="ignore", invalid="ignore"):
        G = np.floor((F - fmin) / d)
    G[G >= div] = div - 1
    G[np.isnan(G)] = 0
    _, site = np.unique(G, axis=0, return_inverse=True)
    return site.ravel()


def _delete(F: np.ndarray, K: int, div: int, rng: np.random.Generator) -> np.ndarray:
    """Delete(PopObj,K,div) of UpdateArchive.m / BCAUpdatePop.m: boolean mask of K deleted rows."""
    N = len(F)
    site = _grid_sites(F, div).astype(float)
    crowd = np.bincount(site.astype(int)).astype(int)
    dele = np.zeros(N, bool)
    while dele.sum() < K:
        max_grid = np.flatnonzero(crowd == crowd.max())
        grid = max_grid[rng.integers(len(max_grid))]
        in_grid = np.flatnonzero(site == grid)
        p = in_grid[rng.integers(len(in_grid))]
        dele[p] = True
        site[p] = np.nan
        crowd[grid] -= 1
    return dele


def _roulette(N: int, fitness: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """RouletteWheelSelection.m (smaller fitness -> larger probability); 0-based indices."""
    f = np.asarray(fitness, float).ravel()
    f = f - min(f.min(), 0) + 1e-6
    c = np.cumsum(1 / f)
    c = c / c.max()
    r = rng.random(N)
    return np.array([np.flatnonzero(x <= c)[0] for x in r], int)


def _rep_selection(F: np.ndarray, N: int, div: int, rng: np.random.Generator) -> np.ndarray:
    """REPSelection.m: one leader per army, roulette over grids by crowding."""
    site = _grid_sites(F, div)
    crowd = np.bincount(site)
    the_grid = _roulette(N, crowd, rng)
    rep = np.empty(N, int)
    for i, g in enumerate(the_grid):
        in_grid = np.flatnonzero(site == g)
        rep[i] = in_grid[rng.integers(len(in_grid))]
    return rep


def _first_front(F: np.ndarray) -> np.ndarray:
    front, _ = nd_sort(F, 1)
    return np.flatnonzero(front == 1)


def _update_archive(X, F, N, div, rng):
    """UpdateArchive.m"""
    keep = _first_front(F)
    X, F = X[keep], F[keep]
    if len(X) > N:
        d = _delete(F, len(X) - N, div, rng)
        X, F = X[~d], F[~d]
    return X, F


def _update_pop(AX, AF, PX, PF, n_armies, div, rng):
    """BCAUpdatePop.m"""
    X, F = np.vstack([AX, PX]), np.vstack([AF, PF])
    keep = _first_front(F)
    X, F = X[keep], F[keep]
    if len(X) > n_armies:
        d = _delete(F, len(X) - n_armies, div, rng)
        X, F = X[~d], F[~d]
    if len(X) >= n_armies:
        return X[:n_armies].copy(), F[:n_armies].copy()
    replace_flag = rng.random(n_armies) < 0.1
    replace_index = np.flatnonzero(replace_flag)
    min_size = min(len(X), len(replace_index))
    index_index = rng.permutation(min_size)
    PX, PF = PX.copy(), PF.copy()
    PX[replace_index[index_index]] = X[:min_size]
    PF[replace_index[index_index]] = F[:min_size]
    return PX, PF


def _operator(problem, P, A, BCB, n_soldiers, n_armies, rng):
    """OperatorBCAGrid.m (decision vectors only; evaluation done by the caller)."""
    D = P.shape[1]
    lower, upper = problem.lower, problem.upper
    out = np.empty((n_armies * n_soldiers, D))
    k = 0
    for i in range(n_armies):
        for _ in range(n_soldiers):
            r = rng.integers(n_armies)
            while r == i:
                r = rng.integers(n_armies)
            dist = np.abs(P[r] - P[i])
            use_b = rng.random(D) < BCB
            ang = rng.random(D) * 2 * np.pi
            s = np.where(use_b, A[i] + dist * np.sin(ang), P[r] + dist * np.cos(ang))
            out[k] = np.maximum(np.minimum(s, upper), lower)
            k += 1
    return out


def run(problem, pop_size: int, rng: np.random.Generator, callback=None,
        BCB: float = 0.2, nSoldiers: int = 3, div: int = 10):
    N = pop_size
    n_armies = int(N // nSoldiers)  # fix(Problem.N/nSoldiers)
    if n_armies < 2:
        raise ValueError("MOBCA needs at least 2 armies (pop_size >= 2*nSoldiers)")

    # Initialization(nArmies)
    if hasattr(problem, "initial_population"):
        PX = np.asarray(problem.initial_population(n_armies, rng), float)
    else:
        PX = rng.uniform(problem.lower, problem.upper, size=(n_armies, problem.n_var))
    PX = PX[: problem.remaining]
    PF = problem.evaluate(PX)
    AX, AF = PX.copy(), PF.copy()

    while True:
        # NotTerminated(Archive)
        if callback is not None:
            callback(problem, AX, AF)
        if problem.exhausted:
            break
        rep = _rep_selection(AF, n_armies, div, rng)
        OX = _operator(problem, PX, AX[rep], BCB, nSoldiers, n_armies, rng)
        OX = OX[: problem.remaining]
        OF = problem.evaluate(OX)
        AX, AF = _update_archive(np.vstack([AX, OX]), np.vstack([AF, OF]), N, div, rng)
        PX, PF = _update_pop(AX, AF, PX, PF, n_armies, div, rng)
    return AX, AF
