"""
Common interface and PlatEMO-equivalent utilities for the implemented MOEAs.

Every algorithm module in this package exposes

    run(problem, pop_size, rng, callback=None, **params) -> (X, F)

* ``problem`` is a ``BaseProblem``: it has ``n_var``, ``n_obj``, ``lower``,
  ``upper``, ``encoding`` ("real" or "binary"), ``max_evals``, and
  ``evaluate(X) -> F``, which counts evaluations. Algorithms run until
  ``problem.exhausted`` and must never call ``evaluate`` with more rows than
  ``problem.remaining``.
* ``callback(problem, X, F)`` is called once per generation with the current
  population.
* ``(X, F)`` is the final population (PlatEMO's ``Population``); metrics are
  computed on its non-dominated subset, as PlatEMO's ``Population.best``.

The utilities below follow the PlatEMO 4.x MATLAB code line by line
(NDSort, CrowdingDistance, TournamentSelection, OperatorGA, UniformPoint),
so that ported algorithms behave as their reference implementations.
"""

from __future__ import annotations

from math import comb

import numpy as np


# ------------------------------------------------------------- problems ---
class BaseProblem:
    encoding = "real"

    def __init__(self, n_var: int, n_obj: int, lower, upper, max_evals: int):
        self.n_var, self.n_obj, self.max_evals = n_var, n_obj, max_evals
        self.lower = np.broadcast_to(np.asarray(lower, float), (n_var,)).copy()
        self.upper = np.broadcast_to(np.asarray(upper, float), (n_var,)).copy()
        self.n_evals = 0

    @property
    def remaining(self) -> int:
        return max(self.max_evals - self.n_evals, 0)

    @property
    def exhausted(self) -> bool:
        return self.n_evals >= self.max_evals

    def evaluate(self, X: np.ndarray) -> np.ndarray:
        X = np.atleast_2d(X)
        if len(X) > self.remaining:
            raise RuntimeError(f"evaluation budget exceeded: {len(X)} requested, {self.remaining} left")
        self.n_evals += len(X)
        return self._evaluate(X)

    def _evaluate(self, X: np.ndarray) -> np.ndarray:
        raise NotImplementedError


# ------------------------------------------------------- sorting etc. ---
def nd_sort(F: np.ndarray, n_sort: int | float = np.inf) -> tuple[np.ndarray, float]:
    """PlatEMO NDSort: front number of each row (inf beyond the first n_sort rows' fronts)."""
    F = np.asarray(F, float)
    N = len(F)
    front = np.full(N, np.inf)
    if N == 0:
        return front, 0
    # dominance matrix: D[i, j] = i dominates j
    le = (F[:, None, :] <= F[None, :, :]).all(axis=2)
    lt = (F[:, None, :] < F[None, :, :]).any(axis=2)
    D = le & lt
    n_dom = D.sum(axis=0).astype(int)
    current = np.flatnonzero(n_dom == 0)
    k, n_assigned = 0, 0
    while len(current) and n_assigned < min(n_sort, N):
        k += 1
        front[current] = k
        n_assigned += len(current)
        n_dom = n_dom - D[current].sum(axis=0)
        n_dom[current] = -1
        current = np.flatnonzero(n_dom == 0)
    return front, k


def crowding_distance(F: np.ndarray, front: np.ndarray | None = None) -> np.ndarray:
    """PlatEMO CrowdingDistance (per front; boundary points get inf)."""
    F = np.asarray(F, float)
    N, M = F.shape
    if front is None:
        front = np.ones(N)
    cd = np.zeros(N)
    for f in np.unique(front[np.isfinite(front)]):
        idx = np.flatnonzero(front == f)
        fmax, fmin = F[idx].max(axis=0), F[idx].min(axis=0)
        for m in range(M):
            order = np.argsort(F[idx, m], kind="stable")
            cd[idx[order[0]]] = np.inf
            cd[idx[order[-1]]] = np.inf
            span = fmax[m] - fmin[m]
            for j in range(1, len(idx) - 1):
                cd[idx[order[j]]] += (F[idx[order[j + 1]], m] - F[idx[order[j - 1]], m]) / span if span > 0 else 0.0
    return cd


def tournament_selection(K: int, N: int, *fitness, rng: np.random.Generator) -> np.ndarray:
    """PlatEMO TournamentSelection: lexicographic on the fitness arrays, smaller is better.

    Known deviation: PlatEMO gives tied fitness rows the same rank, so the
    first-drawn candidate wins a tie; here ties are broken by population index.
    """
    keys = [np.asarray(f, float).ravel() for f in fitness]
    n = len(keys[0])
    rank = np.empty(n, int)
    rank[np.lexsort(tuple(reversed(keys)))] = np.arange(n)
    parents = rng.integers(0, n, size=(K, N))
    best = np.argmin(rank[parents], axis=0)
    return parents[best, np.arange(N)]


def uniform_point(N: int, M: int) -> np.ndarray:
    """PlatEMO UniformPoint with the default NBI method."""
    H1 = 1
    while comb(H1 + M, M - 1) <= N:
        H1 += 1
    W = _nbi(H1, M)
    if H1 < M:
        H2 = 0
        while comb(H1 + M - 1, M - 1) + comb(H2 + M, M - 1) <= N:
            H2 += 1
        if H2 > 0:
            W = np.vstack([W, _nbi(H2, M) / 2 + 1 / (2 * M)])
    return np.maximum(W, 1e-6)


def _nbi(H: int, M: int) -> np.ndarray:
    from itertools import combinations
    C = np.array(list(combinations(range(1, H + M), M - 1))) - np.arange(M - 1) - 1
    return (np.hstack([C, np.full((len(C), 1), H)]) - np.hstack([np.zeros((len(C), 1)), C])) / H


# ------------------------------------------------------------ operators ---
def operator_ga(problem: BaseProblem, P1: np.ndarray, P2: np.ndarray, rng: np.random.Generator,
                proC: float = 1.0, disC: float = 20, proM: float = 1.0, disM: float = 20) -> np.ndarray:
    """PlatEMO OperatorGA: 2*len(P1) offspring (SBX + polynomial mutation, or uniform crossover + bit flip)."""
    if problem.encoding == "binary":
        return _ga_binary(P1, P2, rng, proC, proM)
    return _ga_real(P1, P2, problem.lower, problem.upper, rng, proC, disC, proM, disM)


def operator_ga_half(problem, P1, P2, rng, **kw) -> np.ndarray:
    """PlatEMO OperatorGAhalf: first half of OperatorGA's offspring."""
    return operator_ga(problem, P1, P2, rng, **kw)[: len(P1)]


def _ga_real(P1, P2, lower, upper, rng, proC, disC, proM, disM):
    N, D = P1.shape
    mu = rng.random((N, D))
    beta = np.where(mu <= 0.5, (2 * mu) ** (1 / (disC + 1)), (2 - 2 * mu) ** (-1 / (disC + 1)))
    beta = beta * (-1.0) ** rng.integers(0, 2, (N, D))
    beta[rng.random((N, D)) < 0.5] = 1
    beta[np.repeat(rng.random((N, 1)) > proC, D, axis=1)] = 1
    O = np.vstack([(P1 + P2) / 2 + beta * (P1 - P2) / 2, (P1 + P2) / 2 - beta * (P1 - P2) / 2])
    return polynomial_mutation(O, lower, upper, rng, proM, disM)


def polynomial_mutation(O, lower, upper, rng, proM=1.0, disM=20.0):
    n, D = O.shape
    L, U = np.broadcast_to(lower, (n, D)), np.broadcast_to(upper, (n, D))
    site = rng.random((n, D)) < proM / D
    mu = rng.random((n, D))
    O = np.minimum(np.maximum(O, L), U)
    with np.errstate(divide="ignore", invalid="ignore"):
        t = site & (mu <= 0.5)
        O[t] = O[t] + (U[t] - L[t]) * ((2 * mu[t] + (1 - 2 * mu[t]) *
                                         (1 - (O[t] - L[t]) / (U[t] - L[t])) ** (disM + 1)) ** (1 / (disM + 1)) - 1)
        t = site & (mu > 0.5)
        O[t] = O[t] + (U[t] - L[t]) * (1 - (2 * (1 - mu[t]) + 2 * (mu[t] - 0.5) *
                                             (1 - (U[t] - O[t]) / (U[t] - L[t])) ** (disM + 1)) ** (1 / (disM + 1)))
    return O


def _ga_binary(P1, P2, rng, proC, proM):
    N, D = P1.shape
    k = rng.random((N, D)) < 0.5
    k[np.repeat(rng.random((N, 1)) > proC, D, axis=1)] = False
    O1, O2 = P1.copy(), P2.copy()
    O1[k], O2[k] = P2[k], P1[k]
    O = np.vstack([O1, O2]).astype(bool)
    site = rng.random(O.shape) < proM / D
    O[site] = ~O[site]
    return O


# -------------------------------------------------------------- metrics ---
def igd(F: np.ndarray, optimum: np.ndarray) -> float:
    from scipy.spatial.distance import cdist
    return float(cdist(optimum, F).min(axis=1).mean())


def igd_plus(F: np.ndarray, optimum: np.ndarray, chunk: int = 20000) -> float:
    out = []
    for s in range(0, len(optimum), chunk):
        R = optimum[s:s + chunk]
        d = np.sqrt((np.maximum(F[None, :, :] - R[:, None, :], 0) ** 2).sum(axis=2))
        out.append(d.min(axis=1))
    return float(np.concatenate(out).mean())


def best(F: np.ndarray) -> np.ndarray:
    """Indices of the non-dominated rows (PlatEMO Population.best for unconstrained problems)."""
    front, _ = nd_sort(F, 1)
    return np.flatnonzero(front == 1)
