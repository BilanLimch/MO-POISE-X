"""
Training-side rules that pick panels from a front.

Every rule here sees only inner-CV quantities (error, its SE, cost, size),
never outer-test scores, so the panel it returns can be evaluated on the
outer test fold without selection bias.

* ``one_se_rule`` -- among the panels whose inner error is within one SE of
  the lowest inner error, take the one with the lowest assay cost, then the
  smallest size, then the lowest error.
* ``per_cost_rule`` -- for every assay budget c, apply ``one_se_rule`` to the
  panels with cost <= c. This gives the "best panel using at most c assays"
  curve, the clinically relevant summary of the front.
"""

from __future__ import annotations

import numpy as np
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting


def nondominated(F: np.ndarray) -> np.ndarray:
    """Indices of the non-dominated rows of F (minimization)."""
    F = np.atleast_2d(F)
    if len(F) == 0:
        return np.array([], dtype=int)
    return np.asarray(NonDominatedSorting().do(F, only_non_dominated_front=True), dtype=int)


def one_se_rule(error: np.ndarray, error_se: np.ndarray, cost: np.ndarray, size: np.ndarray,
                candidates: np.ndarray | None = None) -> int | None:
    idx = np.arange(len(error)) if candidates is None else np.asarray(candidates, dtype=int)
    if len(idx) == 0:
        return None
    best = idx[np.argmin(error[idx])]
    within = idx[error[idx] <= error[best] + error_se[best]]
    order = np.lexsort((error[within], size[within], cost[within]))
    return int(within[order[0]])


def per_cost_rule(error, error_se, cost, size) -> dict[float, int]:
    out: dict[float, int] = {}
    for c in np.unique(cost):
        pick = one_se_rule(error, error_se, cost, size, candidates=np.flatnonzero(cost <= c))
        if pick is not None:
            out[float(c)] = pick
    return out
