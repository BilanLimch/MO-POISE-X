"""
TCGA-UCEC multi-omics cohort loader.

Two stages, deliberately separated:

1. ``build_cache()`` (run once, ``python -m mopoise.data --build``): reads the
   raw UCSC-Xena matrices, keeps ONE primary-tumour sample per cohort patient,
   and writes each modality as a compact float32 ``.npz`` (patients x features)
   plus the effective cohort table. This stage is *label-free and
   fold-agnostic*: the only feature removal it performs is dropping features
   that are constant or contain NaN across the whole cohort. Removing a
   constant feature cannot leak anything (it is constant in every subset),
   and NaN removal is required for every downstream classifier anyway.

2. ``load_dataset()`` (every experiment): loads the cache into a
   ``UcecDataset``. Any *statistical* pre-filtering (variance ranking,
   ANOVA, mutation-frequency cut-offs, clinical imputation) is NOT done
   here -- that lives in ``prefilter.py`` and must be called inside each
   outer training fold (Ambroise & McLachlan 2002 leakage rule).

Sample selection rule (TCGA barcode ``TCGA-XX-XXXX-TTV``): only sample type
``01`` (primary solid tumour) is used; ``11`` (solid tissue normal) and
``02`` (recurrent) are ignored. Among several ``01`` vials the lowest vial
letter wins (01A < 01B < 01C). A cohort patient whose *tumour* sample is
missing in a modality (the cohort intersection in ``check_overlap.py`` was
computed on any sample type) is dropped from the effective cohort and
reported in ``cache_summary.json``.
"""

from __future__ import annotations

import argparse
import gzip
import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

RAW_DIR = Path(os.environ.get("UCEC_RAW_DIR", "raw"))
CACHE_DIR = Path(os.environ.get("UCEC_CACHE_DIR", Path(__file__).resolve().parents[1] / "data"))

# Fixed class order everywhere (labels are integers 0..3 in this order).
CLASS_NAMES: tuple[str, ...] = ("UCEC_POLE", "UCEC_MSI", "UCEC_CN_LOW", "UCEC_CN_HIGH")
CLASS_TO_INT = {c: i for i, c in enumerate(CLASS_NAMES)}

OMICS_FILES = {
    "rna": "TCGA-UCEC.star_fpkm.tsv.gz",          # log2(FPKM+1), Ensembl gene ids
    "mirna": "TCGA-UCEC.mirna.tsv.gz",            # log2(RPM+1), miRNA ids
    "meth": "TCGA-UCEC.methylation450.tsv.gz",    # beta values, cg probe ids
    "cnv": "TCGA-UCEC.gene-level_ascat3.tsv.gz",  # absolute copy number per gene (2 = neutral)
}
MUTATION_FILE = "TCGA-UCEC.somaticmutation_wxs.tsv.gz"
CLINICAL_FILE = "TCGA-UCEC.clinical.tsv.gz"
SUBTYPE_FILE = "TCGA-UCEC.molecular_subtype.tsv"
COHORT_FILE = "final_cohort.tsv"

# A variant counts as a (protein-altering) mutation if ANY of its ';'-joined
# VEP effect terms is in this set. Synonymous / intronic / UTR-only calls are
# ignored. This is the conventional non-silent definition, applied identically
# to every patient (label-free, so safe to do at cache time).
NONSILENT_EFFECTS = frozenset({
    "missense_variant", "stop_gained", "stop_lost", "start_lost",
    "frameshift_variant", "inframe_deletion", "inframe_insertion",
    "splice_acceptor_variant", "splice_donor_variant",
})

ALL_MODALITIES: tuple[str, ...] = ("rna", "mirna", "meth", "cnv", "mut", "clin")


# ---------------------------------------------------------------- helpers ---
def patient_of(barcode: str) -> str:
    return "-".join(barcode.split("-")[:3])


def _sample_type(barcode: str) -> str:
    parts = barcode.split("-")
    return parts[3][:2] if len(parts) > 3 else ""


def _vial(barcode: str) -> str:
    parts = barcode.split("-")
    return parts[3][2:] if len(parts) > 3 else ""


def pick_primary_samples(barcodes: list[str], patients: list[str]) -> dict[str, str]:
    """Map each patient to its single preferred primary-tumour barcode."""
    best: dict[str, str] = {}
    wanted = set(patients)
    for bc in barcodes:
        if _sample_type(bc) != "01":
            continue
        p = patient_of(bc)
        if p not in wanted:
            continue
        if p not in best or _vial(bc) < _vial(best[p]):
            best[p] = bc
    return best


def load_cohort_table() -> pd.DataFrame:
    df = pd.read_csv(RAW_DIR / COHORT_FILE, sep="\t")
    unknown = set(df["subtype"]) - set(CLASS_NAMES)
    if unknown:
        raise ValueError(f"unexpected subtype labels in cohort file: {unknown}")
    return df.sort_values("patientId").reset_index(drop=True)


# --------------------------------------------------------- matrix readers ---
def _read_header(path: Path) -> list[str]:
    with gzip.open(path, "rt") as f:
        return f.readline().rstrip("\n").split("\t")


def read_omics_matrix(name: str, patients: list[str]) -> tuple[pd.DataFrame, list[str]]:
    """Return (patients x features float32 DataFrame, patients missing a tumour sample)."""
    path = RAW_DIR / OMICS_FILES[name]
    header = _read_header(path)
    id_col = header[0]
    chosen = pick_primary_samples(header[1:], patients)
    missing = [p for p in patients if p not in chosen]
    kept_patients = [p for p in patients if p in chosen]
    usecols = [id_col] + [chosen[p] for p in kept_patients]
    df = pd.read_csv(path, sep="\t", usecols=usecols, index_col=0,
                     dtype={c: np.float32 for c in usecols[1:]})
    df = df[[chosen[p] for p in kept_patients]]      # enforce cohort order
    df.columns = kept_patients
    return df.T, missing


def read_mutation_matrix(patients: list[str]) -> tuple[pd.DataFrame, list[str]]:
    """Binary patients x genes matrix of non-silent somatic mutations."""
    path = RAW_DIR / MUTATION_FILE
    raw = pd.read_csv(path, sep="\t", usecols=["sample", "gene", "effect"], dtype=str)
    chosen = pick_primary_samples(sorted(raw["sample"].unique()), patients)
    missing = [p for p in patients if p not in chosen]
    kept_patients = [p for p in patients if p in chosen]
    sample_to_patient = {bc: p for p, bc in chosen.items()}
    raw = raw[raw["sample"].isin(sample_to_patient)]
    nonsilent = raw["effect"].fillna("").map(
        lambda e: any(t in NONSILENT_EFFECTS for t in e.split(";")))
    raw = raw[nonsilent]
    raw = raw.assign(patient=raw["sample"].map(sample_to_patient))
    mat = pd.crosstab(raw["patient"], raw["gene"]).reindex(kept_patients, fill_value=0)
    mat = (mat > 0).astype(np.float32)
    return mat, missing


def read_clinical(patients: list[str]) -> tuple[pd.DataFrame, list[str]]:
    """Structured clinical features. Grade is 'Not Reported'
    for every TCGA-UCEC case in the GDC table, so it is omitted.

    Columns: age (years, NaN if missing -- impute *inside the fold*),
    figo_stage (ordinal 1-4 from the FIGO stage string, NaN if missing),
    hist_endometrioid / hist_serous / hist_other (one-hot histology).
    """
    path = RAW_DIR / CLINICAL_FILE
    raw = pd.read_csv(path, sep="\t", dtype=str)
    chosen = pick_primary_samples(list(raw["sample"]), patients)
    missing = [p for p in patients if p not in chosen]
    kept_patients = [p for p in patients if p in chosen]
    raw = raw.set_index("sample").loc[[chosen[p] for p in kept_patients]]
    raw.index = kept_patients

    def stage_ordinal(s):
        if not isinstance(s, str) or not s.startswith("Stage "):
            return np.nan
        roman = s.split()[1].rstrip("ABC0123456789")
        return {"I": 1.0, "II": 2.0, "III": 3.0, "IV": 4.0}.get(roman, np.nan)

    def hist_group(s):
        s = (s or "").lower()
        if "endometrioid" in s:
            return "endometrioid"
        if "serous" in s:
            return "serous"
        return "other"

    age = pd.to_numeric(raw["age_at_index.demographic"], errors="coerce")
    stage = raw["figo_stage.diagnoses"].map(stage_ordinal)
    hist = raw["primary_diagnosis.diagnoses"].map(hist_group)
    out = pd.DataFrame({
        "age": age.astype(np.float32),
        "figo_stage": stage.astype(np.float32),
        "hist_endometrioid": (hist == "endometrioid").astype(np.float32),
        "hist_serous": (hist == "serous").astype(np.float32),
        "hist_other": (hist == "other").astype(np.float32),
    }, index=kept_patients)
    return out, missing


# ------------------------------------------------------------ cache build ---
def _clean_features(df: pd.DataFrame, name: str, log: dict) -> pd.DataFrame:
    """Drop features with any NaN, then constant features. Label-free."""
    n0 = df.shape[1]
    df = df.loc[:, ~df.isna().any(axis=0)]
    n1 = df.shape[1]
    df = df.loc[:, df.nunique(axis=0) > 1]
    n2 = df.shape[1]
    log[name] = {"raw_features": n0, "dropped_nan": n0 - n1, "dropped_constant": n1 - n2, "kept": n2}
    return df


def build_cache(modalities: tuple[str, ...] = ALL_MODALITIES) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cohort = load_cohort_table()
    patients = list(cohort["patientId"])
    print(f"cohort file: {len(patients)} patients")

    blocks: dict[str, pd.DataFrame] = {}
    missing_log: dict[str, list[str]] = {}
    feature_log: dict[str, dict] = {}
    for name in modalities:
        t0 = time.time()
        if name == "clin":
            df, missing = read_clinical(patients)
            # clinical NaNs (age/stage) are legitimate and imputed in-fold
            feature_log[name] = {"raw_features": df.shape[1], "kept": df.shape[1],
                                 "n_missing_age": int(df["age"].isna().sum()),
                                 "n_missing_stage": int(df["figo_stage"].isna().sum())}
        elif name == "mut":
            df, missing = read_mutation_matrix(patients)
            df = _clean_features(df, name, feature_log)
        else:
            df, missing = read_omics_matrix(name, patients)
            df = _clean_features(df, name, feature_log)
        blocks[name] = df
        missing_log[name] = missing
        print(f"  {name:6s}: {df.shape[0]} patients x {df.shape[1]} features "
              f"({len(missing)} cohort patients lack a primary-tumour sample)  [{time.time()-t0:.0f}s]")

    # Effective cohort = patients present (with a tumour sample) in every modality.
    effective = [p for p in patients if all(p in b.index for b in blocks.values())]
    dropped = [p for p in patients if p not in effective]
    cohort_eff = cohort[cohort["patientId"].isin(effective)].reset_index(drop=True)
    cohort_eff["y"] = cohort_eff["subtype"].map(CLASS_TO_INT)
    cohort_eff.to_csv(CACHE_DIR / "cohort.tsv", sep="\t", index=False)

    for name, df in blocks.items():
        df = df.loc[effective]
        np.savez_compressed(CACHE_DIR / f"ucec_{name}.npz",
                            X=df.to_numpy(np.float32), features=np.asarray(df.columns, dtype=str))

    summary = {
        "n_cohort_file": len(patients),
        "n_effective": len(effective),
        "dropped_patients": dropped,
        "missing_tumour_sample_by_modality": missing_log,
        "features": feature_log,
        "class_counts": {c: int((cohort_eff["subtype"] == c).sum()) for c in CLASS_NAMES},
        "class_order": list(CLASS_NAMES),
        "sample_rule": "type 01 only, lowest vial letter; 02/11 ignored",
    }
    with open(CACHE_DIR / "cache_summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps({k: v for k, v in summary.items() if k != "missing_tumour_sample_by_modality"}, indent=2))


# ---------------------------------------------------------------- loading ---
@dataclass
class Block:
    X: np.ndarray            # (n_patients, n_features) float32
    features: np.ndarray     # (n_features,) str

    @property
    def n_features(self) -> int:
        return self.X.shape[1]


@dataclass
class UcecDataset:
    patients: np.ndarray                     # (n,) str
    y: np.ndarray                            # (n,) int in 0..3
    class_names: tuple[str, ...] = CLASS_NAMES
    blocks: dict[str, Block] = field(default_factory=dict)

    @property
    def n(self) -> int:
        return len(self.patients)


def load_dataset(modalities: tuple[str, ...] = ALL_MODALITIES) -> UcecDataset:
    cohort = pd.read_csv(CACHE_DIR / "cohort.tsv", sep="\t")
    ds = UcecDataset(patients=cohort["patientId"].to_numpy(str), y=cohort["y"].to_numpy(int))
    for name in modalities:
        z = np.load(CACHE_DIR / f"ucec_{name}.npz", allow_pickle=False)
        X, feats = z["X"], z["features"]
        if X.shape[0] != ds.n:
            raise ValueError(f"{name}: {X.shape[0]} rows but cohort has {ds.n}")
        ds.blocks[name] = Block(X=X, features=feats.astype(str))
    return ds


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--build", action="store_true", help="build the .npz cache from raw Xena files")
    ap.add_argument("--modalities", nargs="*", default=list(ALL_MODALITIES))
    args = ap.parse_args()
    if args.build:
        build_cache(tuple(args.modalities))
    else:
        ds = load_dataset(tuple(args.modalities))
        print(f"{ds.n} patients; classes {dict(zip(ds.class_names, np.bincount(ds.y, minlength=4)))}")
        for k, b in ds.blocks.items():
            print(f"  {k:6s}: {b.X.shape}")
