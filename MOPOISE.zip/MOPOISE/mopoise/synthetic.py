"""
Synthetic data shaped like the TCGA-UCEC cohort, for tests and smoke runs.

369 patients, four imbalanced classes (POLE / MSI / CN-low / CN-high,
10/28/28/34%), the six blocks of the real data at reduced width. The class
signal is placed in three blocks only (meth, cnv, mut), so a good front
should reach a low error without rna and mirna, i.e. at assay cost <= 3.
"""

from __future__ import annotations

import numpy as np
from sklearn.datasets import make_classification

from mopoise.data import Block, UcecDataset

BLOCK_WIDTHS = {"rna": 300, "mirna": 100, "meth": 300, "cnv": 200, "mut": 100}
# informative columns 0..11 and redundant columns 12..17 of make_classification
SIGNAL_COLUMNS = {"meth": [0, 1, 2, 3, 4, 12, 13], "cnv": [5, 6, 7, 8, 14, 15], "mut": [9, 10, 11, 16, 17]}


def make_synthetic_dataset(seed: int = 0, n: int = 369) -> UcecDataset:
    n_total = sum(BLOCK_WIDTHS.values())
    X, y = make_classification(
        n_samples=n, n_features=n_total, n_informative=12, n_redundant=6, n_classes=4,
        n_clusters_per_class=1, weights=[0.10, 0.28, 0.28, 0.34], flip_y=0.03,
        class_sep=1.0, shuffle=False, random_state=seed,
    )
    rng = np.random.default_rng(seed)
    noise_cols = list(range(18, n_total))
    rng.shuffle(noise_cols)

    ds = UcecDataset(patients=np.array([f"SYN-{i:04d}" for i in range(n)]), y=y.astype(int))
    for block, width in BLOCK_WIDTHS.items():
        sig = SIGNAL_COLUMNS.get(block, [])
        cols = sig + [noise_cols.pop() for _ in range(width - len(sig))]
        Xb = X[:, cols].astype(np.float32)
        if block == "mut":
            Xb = (Xb > 0.8).astype(np.float32)     # sparse binary, like non-silent mutation calls
        ds.blocks[block] = Block(X=Xb, features=np.array([f"{block}_{j}" for j in range(width)]))

    age = rng.normal(63, 10, n).astype(np.float32)
    age[rng.random(n) < 0.02] = np.nan
    stage = rng.integers(1, 5, n).astype(np.float32)
    hist = np.where(rng.random(n) < 0.3, y == 3, rng.random(n) < 0.2)   # serous loosely tracks CN-high
    other = ~hist & (rng.random(n) < 0.05)
    endo = ~hist & ~other
    clin = np.column_stack([age, stage, endo, hist, other]).astype(np.float32)
    ds.blocks["clin"] = Block(X=clin, features=np.array(["age", "figo_stage", "hist_endometrioid", "hist_serous", "hist_other"]))
    return ds
