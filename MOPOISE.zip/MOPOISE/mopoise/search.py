"""
Multi-objective search over binary feature masks (pymoo).

Decision vector: one bit per candidate feature of the fold's pool (N bits).
Objectives: ``PanelEvaluator.objectives`` (error, assay cost, |S|/N).
The empty panel, which would otherwise be trivially non-dominated on cost and
size, is excluded by ``NonEmptyRepair`` (one random feature is switched on in
any empty mask) rather than by a constraint, because several of the compared
algorithms have no constraint handling.

Problem-specific operators, shared by every algorithm:

* ``BlockSparseSampling`` -- each initial individual uses a random subset of
  the data blocks and a low, log-uniform feature density inside them.
  Uniform 0.5 sampling would start every individual at ~N/2 features and
  every block active, i.e. in one corner of the objective space.
* ``BlockAwareMutation`` -- bit-flip mutation plus, with probability
  ``p_block_drop``, removal of one whole active block. Reaching a lower assay
  cost by flipping single bits requires every feature of a block to be
  removed at once, which bit-flip alone essentially never does.
* ``NonEmptyRepair`` -- see above.

Every algorithm gets the same population size, the same operators and the
same evaluation budget; algorithm-specific parameters are left at the
defaults of their reference implementation.
"""

from __future__ import annotations

import numpy as np
from pymoo.algorithms.moo.age import AGEMOEA
from pymoo.algorithms.moo.age2 import AGEMOEA2
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.algorithms.moo.omni import OmniOptimizer
from pymoo.algorithms.moo.rvea import RVEA
from pymoo.algorithms.moo.sms import SMSEMOA
from pymoo.algorithms.moo.spea2 import SPEA2
from pymoo.algorithms.moo.unsga3 import UNSGA3
from pymoo.core.callback import Callback
from pymoo.core.mutation import Mutation
from pymoo.core.problem import Problem
from pymoo.core.repair import Repair
from pymoo.core.sampling import Sampling
from pymoo.indicators.hv import HV
from pymoo.operators.crossover.ux import UniformCrossover
from pymoo.util.ref_dirs import get_reference_directions

from mopoise.objectives import PanelEvaluator

PYMOO_ALGORITHMS: tuple[str, ...] = ("NSGA2", "NSGA3", "UNSGA3", "SPEA2", "RVEA", "SMSEMOA",
                                      "AGEMOEA", "AGEMOEA2", "OMNI")
HV_REF_POINT = np.array([1.1, 1.1, 1.1])   # in normalized objective space, see ``normalize``


class PanelProblem(Problem):
    def __init__(self, evaluator: PanelEvaluator):
        self.evaluator = evaluator
        super().__init__(n_var=evaluator.n_features, n_obj=3, xl=0, xu=1, vtype=bool)

    def _evaluate(self, X, out, *args, **kwargs):
        X = np.asarray(X, dtype=bool)
        out["F"] = np.array([self.evaluator.objectives(x) for x in X])


class NonEmptyRepair(Repair):
    def _do(self, problem, X, random_state=None, **kwargs):
        X = np.asarray(X, dtype=bool).copy()
        rng = random_state if random_state is not None else np.random.default_rng()
        for i in np.flatnonzero(~X.any(axis=1)):
            X[i, rng.integers(X.shape[1])] = True
        return X


class BlockSparseSampling(Sampling):
    def __init__(self, block_slices: dict[str, slice], density: tuple[float, float] = (0.005, 0.2)):
        super().__init__()
        self.slices = list(block_slices.values())
        self.log_lo, self.log_hi = np.log(density[0]), np.log(density[1])

    def _do(self, problem, n_samples, *args, random_state=None, **kwargs):
        rng = random_state
        X = np.zeros((n_samples, problem.n_var), dtype=bool)
        for i in range(n_samples):
            n_blocks = rng.integers(1, len(self.slices) + 1)
            for j in rng.choice(len(self.slices), size=n_blocks, replace=False):
                sl = self.slices[j]
                d = np.exp(rng.uniform(self.log_lo, self.log_hi))
                X[i, sl] = rng.random(sl.stop - sl.start) < d
            if not X[i].any():
                sl = self.slices[rng.integers(len(self.slices))]
                X[i, rng.integers(sl.start, sl.stop)] = True
        return X


class FlatSparseSampling(Sampling):
    """Ablation of ``BlockSparseSampling`` without the block step: one log-uniform density per
    individual, applied to all N features, so that (almost) every block is active."""

    def __init__(self, density: tuple[float, float] = (0.005, 0.2)):
        super().__init__()
        self.log_lo, self.log_hi = np.log(density[0]), np.log(density[1])

    def _do(self, problem, n_samples, *args, random_state=None, **kwargs):
        rng = random_state
        d = np.exp(rng.uniform(self.log_lo, self.log_hi, size=(n_samples, 1)))
        X = rng.random((n_samples, problem.n_var)) < d
        for i in np.flatnonzero(~X.any(axis=1)):
            X[i, rng.integers(problem.n_var)] = True
        return X


class UniformBitSampling(Sampling):
    """Ablation: the usual binary initialization, every feature selected with probability 0.5."""

    def _do(self, problem, n_samples, *args, random_state=None, **kwargs):
        return random_state.random((n_samples, problem.n_var)) < 0.5


INIT_CHOICES: tuple[str, ...] = ("block", "flat", "uniform")


class BlockAwareMutation(Mutation):
    def __init__(self, block_slices: dict[str, slice], p_block_drop: float = 0.1, prob_var: float | None = None):
        super().__init__(prob=1.0)
        self.slices = list(block_slices.values())
        self.p_block_drop = p_block_drop
        self.bit_prob = prob_var

    def _do(self, problem, X, random_state=None, **kwargs):
        rng = random_state
        p = self.bit_prob if self.bit_prob is not None else 1.0 / problem.n_var
        Xp = np.asarray(X, dtype=bool).copy()
        flip = rng.random(Xp.shape) < p
        Xp[flip] = ~Xp[flip]
        for i in np.flatnonzero(rng.random(len(Xp)) < self.p_block_drop):
            active = [sl for sl in self.slices if Xp[i, sl].any()]
            if len(active) > 1:   # never drop the last block (the panel would become empty)
                Xp[i, active[rng.integers(len(active))]] = False
        return Xp


def normalize(F: np.ndarray, total_cost: float) -> np.ndarray:
    """Map (error, cost, size_frac) to [0, 1]^3 for hypervolume."""
    F = np.atleast_2d(np.asarray(F, dtype=float)).copy()
    F[:, 1] = F[:, 1] / total_cost if total_cost > 0 else 0.0
    return F


def hypervolume(F: np.ndarray, total_cost: float) -> float:
    if len(F) == 0:
        return 0.0
    return float(HV(ref_point=HV_REF_POINT)(normalize(F, total_cost)))


class HypervolumeCallback(Callback):
    """Records (n_evals, hypervolume of the current non-dominated set) every generation."""

    def __init__(self, total_cost: float):
        super().__init__()
        self.total_cost = total_cost
        self.curve: list[tuple[int, float]] = []

    def notify(self, algorithm):
        opt = algorithm.opt
        F = opt.get("F") if opt is not None and len(opt) else np.empty((0, 3))
        self.curve.append((int(algorithm.evaluator.n_eval), hypervolume(F, self.total_cost)))


def sampling_for(init: str, block_slices: dict[str, slice], density: tuple[float, float]) -> Sampling:
    if init == "block":
        return BlockSparseSampling(block_slices, density=density)
    if init == "flat":
        return FlatSparseSampling(density=density)
    if init == "uniform":
        return UniformBitSampling()
    raise ValueError(f"unknown init {init!r}; choose from {INIT_CHOICES}")


def operators(block_slices: dict[str, slice], p_block_drop: float = 0.1,
              density: tuple[float, float] = (0.005, 0.2), init: str = "block") -> dict:
    return dict(
        sampling=sampling_for(init, block_slices, density),
        crossover=UniformCrossover(prob=0.9),
        mutation=BlockAwareMutation(block_slices, p_block_drop=p_block_drop),
        repair=NonEmptyRepair(),
    )


def ref_dirs_for(pop_size: int) -> np.ndarray:
    """pop_size well-spread reference directions for three objectives (Riesz s-energy)."""
    return get_reference_directions("energy", 3, n_points=pop_size, seed=1)


def _pymoo(name: str, block_slices, pop_size: int, **op_kwargs):
    ops = operators(block_slices, **op_kwargs)
    dedup = dict(ops, eliminate_duplicates=True)
    if name == "NSGA2":
        return NSGA2(pop_size=pop_size, **dedup)
    if name == "NSGA3":
        return NSGA3(ref_dirs=ref_dirs_for(pop_size), pop_size=pop_size, **dedup)
    if name == "UNSGA3":
        return UNSGA3(ref_dirs=ref_dirs_for(pop_size), pop_size=pop_size, **dedup)
    if name == "SPEA2":
        return SPEA2(pop_size=pop_size, **dedup)
    if name == "RVEA":
        return RVEA(ref_dirs=ref_dirs_for(pop_size), pop_size=pop_size, **dedup)
    if name == "SMSEMOA":
        return SMSEMOA(pop_size=pop_size, **dedup)
    if name == "AGEMOEA":
        return AGEMOEA(pop_size=pop_size, **dedup)
    if name == "AGEMOEA2":
        return AGEMOEA2(pop_size=pop_size, **dedup)
    if name == "OMNI":
        return OmniOptimizer(pop_size=pop_size, **dedup)
    raise ValueError(name)


def _recent():
    from mopoise import moeas
    return moeas.REGISTRY


def algorithm_names() -> tuple[str, ...]:
    return PYMOO_ALGORITHMS + tuple(_recent())


def build_algorithm(name: str, block_slices: dict[str, slice], pop_size: int = 50, **op_kwargs):
    if name in PYMOO_ALGORITHMS:
        return _pymoo(name, block_slices, pop_size, **op_kwargs)
    if name in _recent():
        raise ValueError(f"{name} is not a pymoo algorithm; run it through mopoise.moeas")
    raise ValueError(f"unknown algorithm {name!r}; choose from {algorithm_names()}")
