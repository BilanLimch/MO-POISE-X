"""
Three-objective evaluation of a candidate panel (feature mask) inside one
outer training fold.

Objectives, all minimized:
  f1  inner-CV error        1 - mean macro-F1 over the inner splits
  f2  assay cost            sum of the costs of the data blocks that
                            contribute at least one feature to the panel
                            (default: 1 per omics assay, 0 for clinical data)
  f3  panel size            |S| / N

Unlike POISE-X, the classifier is not part of the decision vector: one fixed
classifier (logistic regression by default) is used for every panel, so the
model evaluated on the outer test fold is always the model whose inner score
was optimized.

``X`` and ``y`` passed to ``PanelEvaluator`` must already be restricted to
the outer training fold and to the candidate pool fitted on that fold; this
module has no knowledge of outer folds.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

N_CLASSES = 4
DEFAULT_ASSAY_COST: dict[str, float] = {"rna": 1.0, "mirna": 1.0, "meth": 1.0, "cnv": 1.0, "mut": 1.0, "clin": 0.0}
OBJECTIVE_NAMES: tuple[str, ...] = ("error", "assay_cost", "size_frac")


def build_classifier(name: str, random_state: int):
    if name == "LR":
        return LogisticRegression(max_iter=1000, random_state=random_state)
    if name == "SVM":
        return SVC(kernel="rbf", probability=True, random_state=random_state)
    if name == "RF":
        return RandomForestClassifier(random_state=random_state)
    if name == "KNN":
        return KNeighborsClassifier()
    raise ValueError(f"unknown classifier name: {name!r}")


def fit_predict(clf_name: str, X_tr, y_tr, X_te, random_state: int) -> tuple[np.ndarray, np.ndarray]:
    """z-score on the training rows, fit, and return (pred, proba[:, 0..3]) on X_te."""
    scaler = StandardScaler().fit(X_tr)
    clf = build_classifier(clf_name, random_state).fit(scaler.transform(X_tr), y_tr)
    p = clf.predict_proba(scaler.transform(X_te))
    proba = np.zeros((X_te.shape[0], N_CLASSES))
    proba[:, clf.classes_.astype(int)] = p
    return proba.argmax(axis=1), proba


@dataclass
class ObjectiveConfig:
    classifier: str = "LR"
    k_inner: int = 3
    n_inner_repeats: int = 1
    assay_cost: dict[str, float] = field(default_factory=lambda: dict(DEFAULT_ASSAY_COST))
    random_state: int = 0


@dataclass
class PanelScore:
    scores: np.ndarray          # macro-F1 of each inner split
    error: float                # 1 - mean(scores)
    error_se: float             # SD(scores) / sqrt(n_splits); approximate, splits overlap
    cost: float
    size: int


class PanelEvaluator:
    """Scores feature masks on one outer training fold; results are cached by mask."""

    def __init__(self, X: np.ndarray, y: np.ndarray, block_slices: dict[str, slice], config: ObjectiveConfig):
        self.X, self.y, self.config = X, y, config
        self.n_features = X.shape[1]
        self.blocks = list(block_slices)
        self.block_slices = block_slices
        missing = [b for b in self.blocks if b not in config.assay_cost]
        if missing:
            raise ValueError(f"no assay cost given for blocks {missing}")
        self.block_costs = np.array([config.assay_cost[b] for b in self.blocks], dtype=float)
        self.total_cost = float(self.block_costs.sum())
        # Inner partition fixed once per evaluator (i.e. per run), so the
        # objectives are a deterministic function of the mask within a run.
        rskf = RepeatedStratifiedKFold(n_splits=config.k_inner, n_repeats=config.n_inner_repeats,
                                       random_state=config.random_state)
        self.splits = list(rskf.split(X, y))
        self._cache: dict[bytes, PanelScore] = {}
        self.n_model_evals = 0      # distinct masks actually scored

    def active_blocks(self, mask: np.ndarray) -> list[str]:
        return [b for b in self.blocks if mask[self.block_slices[b]].any()]

    def assay_cost(self, mask: np.ndarray) -> float:
        active = np.array([mask[self.block_slices[b]].any() for b in self.blocks])
        return float(self.block_costs[active].sum())

    def score(self, mask: np.ndarray) -> PanelScore:
        mask = np.asarray(mask, dtype=bool)
        key = np.packbits(mask).tobytes()
        hit = self._cache.get(key)
        if hit is not None:
            return hit
        size = int(mask.sum())
        if size == 0:
            s = PanelScore(scores=np.zeros(len(self.splits)), error=1.0, error_se=0.0, cost=0.0, size=0)
        else:
            Xs = self.X[:, mask]
            scores = np.empty(len(self.splits))
            for i, (tr, va) in enumerate(self.splits):
                pred, _ = fit_predict(self.config.classifier, Xs[tr], self.y[tr], Xs[va], self.config.random_state)
                scores[i] = f1_score(self.y[va], pred, average="macro", labels=range(N_CLASSES))
            se = float(scores.std(ddof=1) / np.sqrt(len(scores))) if len(scores) > 1 else 0.0
            s = PanelScore(scores=scores, error=float(1.0 - scores.mean()), error_se=se,
                           cost=self.assay_cost(mask), size=size)
            self.n_model_evals += 1
        self._cache[key] = s
        return s

    def objectives(self, mask: np.ndarray) -> np.ndarray:
        s = self.score(mask)
        return np.array([s.error, s.cost, s.size / self.n_features])
