"""Fold-wise performance and selection stability of the stored runs (revision).

Reads only results/*/fold*_seed*.json and the filter-front files; no model is fitted.
Writes to results_rev/stability/:
  foldwise.tsv        per outer fold: one-SE macro-F1 and test HV of the ten competitive
                      algorithms (mean, SD, min, max over their 40 runs) and of the filter fronts
  fold_blocks.tsv     per outer fold: share of block combinations of the one-SE panel and of
                      the panel chosen at a budget of two assays (ten competitive algorithms)
  markers.tsv         per outer fold: share of one-SE panels (all thirteen algorithms) that
                      contain each subtype marker
  jaccard.tsv         mean pairwise Jaccard index of one-SE panels, within and between folds
"""
from __future__ import annotations

import glob
import itertools
import json
import os
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd

from mopoise.aggregate import load_run
from mopoise.selection import per_cost_rule

ALGS = ("SPEA2", "SMSEMOA", "OMNI", "NSGA2", "AGEMOEA", "AGEMOEA2", "NSGA3", "UNSGA3", "RVEA",
        "NRVMOEA", "MOBCA", "IMCMOEAD", "TELSO")
COMPETITIVE = ALGS[:10]
FILTERS = {"ANOVA": "baselines", "mRMR": "baselines_mrmr", "L1": "baselines_l1"}
RES = Path("results")
OUT = Path("results_rev/stability")
MLH1_PROBES = Path(os.environ.get("UCEC_CACHE_DIR", "data")) / "mlh1_probes.tsv"
MLH1_RNA = "rna:ENSG00000076242"


def pick_budget2(fr):
    err = np.array([p["inner_error"] for p in fr]); se = np.array([p["inner_error_se"] for p in fr])
    cost = np.array([p["assay_cost"] for p in fr]); size = np.array([p["size"] for p in fr])
    pc = per_cost_rule(err, se, cost, size)
    keys = [k for k in pc if k <= 2.0]
    return fr[pc[max(keys)]] if keys else None


def label(blocks):
    names = {"rna": "mRNA", "mirna": "miRNA", "meth": "Methylation", "cnv": "Copy number", "mut": "Mutation",
             "clin": "Clinical"}
    omics = [names[b] for b in blocks if b != "clin"]
    return " + ".join(omics) if omics else "Clinical only"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    mlh1 = set("meth:" + pd.read_csv(MLH1_PROBES, sep="\t")["id"])
    runs = []
    for alg in ALGS:
        for f in sorted(glob.glob(str(RES / alg / "fold*_seed*.json"))):
            r = load_run(f)
            sel = r["front"][r["selected"]["one_se"]]
            b2 = pick_budget2(r["front"])
            runs.append({"alg": alg, "fold": r["fold"], "seed": r["seed"], "f1": sel["test"]["macro_f1"],
                         "hv": r["hypervolume"]["test"], "features": set(sel["features"]),
                         "blocks": label(sel["blocks"]), "b2_blocks": label(b2["blocks"]) if b2 else "none",
                         "b2_f1": b2["test"]["macro_f1"] if b2 else np.nan})
    runs = pd.DataFrame(runs)
    comp = runs[runs["alg"].isin(COMPETITIVE)]

    rows = []
    for fold, g in comp.groupby("fold"):
        row = {"fold": fold, "n_runs": len(g)}
        for col in ("f1", "hv", "b2_f1"):
            row.update({f"{col}_mean": g[col].mean(), f"{col}_sd": g[col].std(ddof=1),
                        f"{col}_min": g[col].min(), f"{col}_max": g[col].max()})
        for name, d in FILTERS.items():
            P = json.load(open(RES / d / f"fold{fold}.json"))["panels"]
            from mopoise.selection import one_se_rule
            err = np.array([p["inner_error"] for p in P]); se = np.array([p["inner_error_se"] for p in P])
            cost = np.array([p["assay_cost"] for p in P]); size = np.array([p["size"] for p in P])
            row[f"{name}_f1"] = P[one_se_rule(err, se, cost, size)]["test"]["macro_f1"]
        rows.append(row)
    pd.DataFrame(rows).to_csv(OUT / "foldwise.tsv", sep="\t", index=False, float_format="%.4f")

    rows = []
    for fold, g in comp.groupby("fold"):
        for kind, col in (("one_se", "blocks"), ("budget2", "b2_blocks")):
            for combo, n in Counter(g[col]).most_common():
                rows.append({"fold": fold, "panel": kind, "blocks": combo, "count": n, "share": n / len(g)})
    pd.DataFrame(rows).to_csv(OUT / "fold_blocks.tsv", sep="\t", index=False, float_format="%.4f")

    markers = {"RPL22 mutation": lambda s: "mut:RPL22" in s, "TP53 mutation": lambda s: "mut:TP53" in s,
               "POLE mutation": lambda s: "mut:POLE" in s,
               "MLH1-annotated methylation probe (any)": lambda s: bool(s & mlh1),
               "MLH1 expression": lambda s: any(x.startswith(MLH1_RNA) for x in s),
               "MLH1 methylation or expression": lambda s: bool(s & mlh1) or any(x.startswith(MLH1_RNA) for x in s)}
    rows = []
    for scope, data in (("all13", runs), ("competitive10", comp)):
        for name, test in markers.items():
            row = {"scope": scope, "marker": name}
            for fold, g in data.groupby("fold"):
                row[f"fold{fold}"] = np.mean([test(s) for s in g["features"]])
            row["all"] = np.mean([test(s) for s in data["features"]])
            rows.append(row)
    pd.DataFrame(rows).to_csv(OUT / "markers.tsv", sep="\t", index=False, float_format="%.4f")

    def jac(a, b):
        return len(a & b) / len(a | b) if a | b else np.nan

    rows = []
    for scope, data in (("all13", runs), ("competitive10", comp)):
        within, between = [], []
        recs = list(zip(data["fold"], data["features"]))
        for (fa, sa), (fb, sb) in itertools.combinations(recs, 2):
            (within if fa == fb else between).append(jac(sa, sb))
        rows.append({"scope": scope, "jaccard_within_fold": np.mean(within), "jaccard_between_folds": np.mean(between),
                     "n_pairs_within": len(within), "n_pairs_between": len(between)})
    pd.DataFrame(rows).to_csv(OUT / "jaccard.tsv", sep="\t", index=False, float_format="%.4f")
    for f in ("foldwise", "fold_blocks", "markers", "jaccard"):
        print(f"== {f}"); print(pd.read_csv(OUT / f"{f}.tsv", sep="\t").to_string(index=False))


if __name__ == "__main__":
    main()
