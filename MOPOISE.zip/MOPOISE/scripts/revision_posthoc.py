"""Post-hoc evaluation of stored panels for the revision.

For one outer fold, every panel chosen by a training-side rule (one-SE panel,
panel with at most five features, panel at a budget of two assays) of every
MOEA run and of every filter front is refitted on the outer training fold with
logistic regression (LR, the classifier of the search), a random forest (RF),
and an RBF support vector machine (SVM), and scored on the outer test fold:
macro-averaged F1, Cohen's kappa, accuracy, and per-class precision, recall,
and F1. No search is repeated; the panels are those stored in results/.

The fold also evaluates a molecular surrogate of the clinical ProMisE
hierarchy built from the same TCGA data: POLE exonuclease-domain hotspot
mutation -> POLE; else MLH1 promoter hypermethylation or a truncating
mismatch-repair mutation -> MSI; else TP53 mutation -> CN-high; else CN-low.
The MLH1 methylation threshold is the only fitted quantity and is chosen on
the outer training fold.

Usage: python scripts/revision_posthoc.py --fold 0 --out results_rev/posthoc
"""
from __future__ import annotations

import argparse
import glob
import itertools
import json
import os
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_selection import f_classif
from sklearn.metrics import accuracy_score, cohen_kappa_score, f1_score, precision_recall_fscore_support

from mopoise.baselines import M_GRID, baseline_dir, candidate_panels
from mopoise.data import CLASS_NAMES, NONSILENT_EFFECTS, load_dataset, pick_primary_samples
from mopoise.nested_cv import RESULTS_DIR, SEED_BASE, outer_folds
from mopoise.objectives import ObjectiveConfig, PanelEvaluator, fit_predict
from mopoise.prefilter import PrefilterConfig, fit_feature_pool
from mopoise.aggregate import load_run
from mopoise.selection import one_se_rule, per_cost_rule

ALGORITHMS = ("SPEA2", "SMSEMOA", "OMNI", "NSGA2", "AGEMOEA", "AGEMOEA2", "NSGA3", "UNSGA3", "RVEA",
              "NRVMOEA", "MOBCA", "IMCMOEAD", "TELSO")
FILTERS = ("anova", "mrmr", "l1")
CLASSIFIERS = ("LR", "RF", "SVM")
POLE_HOTSPOTS = frozenset({"p.P286R", "p.V411L", "p.S297F", "p.A456P", "p.S459F", "p.F367S", "p.L424I",
                           "p.M295R", "p.P436R", "p.M444K", "p.D368Y"})
MMR_GENES = ("MLH1", "MSH2", "MSH6", "PMS2")
TRUNCATING = frozenset({"stop_gained", "frameshift_variant", "splice_acceptor_variant", "splice_donor_variant"})
MUTATION_FILE = Path(os.environ.get("UCEC_RAW_DIR", "raw")) / "TCGA-UCEC.somaticmutation_wxs.tsv.gz"
MLH1_PROBES = Path(os.environ.get("UCEC_CACHE_DIR", "data")) / "mlh1_probes.tsv"


def metrics(y_true, pred) -> dict:
    labels = list(range(len(CLASS_NAMES)))
    p, r, f, _ = precision_recall_fscore_support(y_true, pred, labels=labels, zero_division=0)
    out = {"macro_f1": f1_score(y_true, pred, labels=labels, average="macro", zero_division=0),
           "kappa": cohen_kappa_score(y_true, pred, labels=labels),
           "accuracy": accuracy_score(y_true, pred)}
    for i, c in enumerate(CLASS_NAMES):
        out[f"precision_{c}"], out[f"recall_{c}"], out[f"f1_{c}"] = p[i], r[i], f[i]
    return out


def chosen_panels(err, se, cost, size) -> dict[str, int]:
    """Training-side choices: one-SE panel, panel with <= 5 features, panel at a budget of two assays."""
    picks = {"one_se": one_se_rule(err, se, cost, size),
             "size5": one_se_rule(err, se, cost, size, candidates=np.flatnonzero(size <= 5))}
    pc = per_cost_rule(err, se, cost, size)
    keys = [k for k in pc if k <= 2.0]
    picks["budget2"] = pc[max(keys)] if keys else None
    return {k: v for k, v in picks.items() if v is not None}


def filter_masks(method, X_tr, y_tr, pool, random_state) -> dict[tuple, list[np.ndarray]]:
    """Panels of a filter front keyed by (block subset, m), as built by mopoise.baselines."""
    F, _ = f_classif(X_tr, y_tr)
    F = np.nan_to_num(F, nan=-np.inf)
    blocks = list(pool.block_slices)
    out = {}
    for r in range(1, len(blocks) + 1):
        for subset in itertools.combinations(blocks, r):
            cols = np.concatenate([np.arange(pool.block_slices[b].start, pool.block_slices[b].stop) for b in subset])
            for m, idx in candidate_panels(method, X_tr, y_tr, F, cols, M_GRID, random_state):
                mask = np.zeros(pool.n_features, dtype=bool)
                mask[idx] = True
                out.setdefault((subset, int(m)), []).append(mask)
    return out


def evaluate(mask, X_tr, y_tr, X_te, y_te, seed) -> list[dict]:
    rows = []
    for clf in CLASSIFIERS:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", ConvergenceWarning)
            pred, _ = fit_predict(clf, X_tr[:, mask], y_tr, X_te[:, mask], seed)
        rows.append({"classifier": clf, **metrics(y_te, pred)})
    return rows


def surrogate(ds, train_idx, test_idx) -> tuple[dict, dict]:
    raw = pd.read_csv(MUTATION_FILE, sep="\t", usecols=["sample", "gene", "Amino_Acid_Change", "effect"], dtype=str)
    chosen = pick_primary_samples(sorted(raw["sample"].unique()), list(ds.patients))
    raw = raw[raw["sample"].isin(set(chosen.values()))].copy()
    raw["patient"] = raw["sample"].map({bc: p for p, bc in chosen.items()})
    terms = raw["effect"].fillna("").str.split(";")
    nonsilent = terms.map(lambda t: any(x in NONSILENT_EFFECTS for x in t))
    trunc = terms.map(lambda t: any(x in TRUNCATING for x in t))
    pole = set(raw.loc[(raw["gene"] == "POLE") & raw["Amino_Acid_Change"].isin(POLE_HOTSPOTS), "patient"])
    mmr_trunc = set(raw.loc[raw["gene"].isin(MMR_GENES) & trunc, "patient"])
    tp53 = set(raw.loc[(raw["gene"] == "TP53") & nonsilent, "patient"])

    probes = pd.read_csv(MLH1_PROBES, sep="\t")
    promoter = set(probes.loc[probes["gene"].str.contains("EPM2AIP1") & probes["gene"].str.contains("MLH1"), "id"])
    meth = ds.blocks["meth"]
    cols = np.flatnonzero(np.isin(meth.features, list(promoter)))
    beta = np.nanmean(meth.X[:, cols], axis=1)

    pts = ds.patients
    is_pole = np.isin(pts, list(pole))
    is_trunc = np.isin(pts, list(mmr_trunc))
    is_tp53 = np.isin(pts, list(tp53))
    msi = CLASS_NAMES.index("UCEC_MSI")

    # MLH1 threshold on the outer training fold: best balanced accuracy for MSI vs. the other classes.
    tr = train_idx[~is_pole[train_idx]]
    yt = ds.y[tr] == msi
    grid = np.unique(np.round(beta[tr], 3))
    bal = [((beta[tr][yt] > t).mean() + (beta[tr][~yt] <= t).mean()) / 2 for t in grid]
    thr = float(grid[int(np.argmax(bal))])

    pred = np.full(ds.n, CLASS_NAMES.index("UCEC_CN_LOW"))
    pred[is_tp53] = CLASS_NAMES.index("UCEC_CN_HIGH")
    pred[(beta > thr) | is_trunc] = msi
    pred[is_pole] = CLASS_NAMES.index("UCEC_POLE")
    info = {"mlh1_threshold": thr, "n_promoter_probes": int(len(cols)),
            "n_pole_hotspot": int(is_pole.sum()), "n_mmr_truncating": int(is_trunc.sum()), "n_tp53": int(is_tp53.sum())}
    return metrics(ds.y[test_idx], pred[test_idx]), info


def main(fold: int, out: Path, results: Path):
    ds = load_dataset()
    train_idx, test_idx = outer_folds(ds)[fold]
    y_tr, y_te = ds.y[train_idx], ds.y[test_idx]
    pool = fit_feature_pool(ds, train_idx, PrefilterConfig(k_per_block=500))
    X_tr, X_te = pool.transform(ds, train_idx), pool.transform(ds, test_idx)
    name_to_col = {n: i for i, n in enumerate(pool.feature_names)}
    rows = []

    for alg in ALGORITHMS:
        for f in sorted(glob.glob(str(results / alg / f"fold{fold}_seed*.json"))):
            r = load_run(f)   # same selected panels; dominated panels are never selected
            fr = r["front"]
            err = np.array([p["inner_error"] for p in fr]); se = np.array([p["inner_error_se"] for p in fr])
            cost = np.array([p["assay_cost"] for p in fr]); size = np.array([p["size"] for p in fr])
            picks = chosen_panels(err, se, cost, size)
            assert picks["one_se"] == r["selected"]["one_se"], f
            for kind, i in picks.items():
                mask = np.zeros(pool.n_features, dtype=bool)
                mask[[name_to_col[n] for n in fr[i]["features"]]] = True
                for row in evaluate(mask, X_tr, y_tr, X_te, y_te, r["seed"]):
                    if row["classifier"] == "LR":
                        assert abs(row["macro_f1"] - fr[i]["test"]["macro_f1"]) < 1e-9, (f, kind)
                    rows.append({"method": alg, "fold": fold, "seed": r["seed"], "panel": kind,
                                 "size": int(mask.sum()), "assay_cost": fr[i]["assay_cost"],
                                 "blocks": "+".join(fr[i]["blocks"]), **row})
        print(f"fold{fold} {alg}: done", flush=True)

    for method in FILTERS:
        P = json.load(open(results / baseline_dir(method) / f"fold{fold}.json"))["panels"]
        evaluator = PanelEvaluator(X_tr, y_tr, pool.block_slices, ObjectiveConfig(random_state=SEED_BASE))
        masks = filter_masks(method, X_tr, y_tr, pool, SEED_BASE)
        err = np.array([p["inner_error"] for p in P]); se = np.array([p["inner_error_se"] for p in P])
        cost = np.array([p["assay_cost"] for p in P]); size = np.array([p["size"] for p in P])
        for kind, i in chosen_panels(err, se, cost, size).items():
            # several L1 supports of a subset can share a size: take the one that reproduces the stored score
            for mask in masks[(tuple(P[i]["blocks"]), int(P[i]["m"]))]:
                if mask.sum() != P[i]["size"]:
                    continue
                pred, _ = fit_predict("LR", X_tr[:, mask], y_tr, X_te[:, mask], SEED_BASE)
                if abs(f1_score(y_te, pred, average="macro", zero_division=0) - P[i]["test"]["macro_f1"]) < 1e-9:
                    break
            else:
                raise AssertionError((method, kind, "no regenerated panel reproduces the stored score"))
            for row in evaluate(mask, X_tr, y_tr, X_te, y_te, SEED_BASE):
                if row["classifier"] == "LR":
                    assert abs(row["macro_f1"] - P[i]["test"]["macro_f1"]) < 1e-9, (method, kind)
                rows.append({"method": method, "fold": fold, "seed": SEED_BASE, "panel": kind,
                             "size": int(mask.sum()), "assay_cost": P[i]["assay_cost"],
                             "blocks": "+".join(evaluator.active_blocks(mask)), **row})
        print(f"fold{fold} {method}: done", flush=True)

    sur, info = surrogate(ds, train_idx, test_idx)
    rows.append({"method": "surrogate", "fold": fold, "seed": -1, "panel": "rule", "size": -1,
                 "assay_cost": 2.0, "blocks": "meth+mut", "classifier": "rule", **sur})
    out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out / f"posthoc_fold{fold}.tsv", sep="\t", index=False)
    json.dump(info, open(out / f"surrogate_fold{fold}.json", "w"), indent=1)
    print(f"fold{fold}: {len(rows)} rows; surrogate {info} macro-F1 {sur['macro_f1']:.3f} kappa {sur['kappa']:.3f}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--fold", type=int, required=True)
    ap.add_argument("--out", type=Path, default=Path("results_rev/posthoc"))
    ap.add_argument("--results", type=Path, default=RESULTS_DIR)
    a = ap.parse_args()
    main(a.fold, a.out, a.results)
