"""Build the strict-intersection cohort table (final_cohort.tsv) from the raw
UCSC Xena TCGA-UCEC files and the cBioPortal subtype labels.

    UCEC_RAW_DIR=/path/to/raw python scripts/build_cohort.py
"""
import gzip, csv, json, os
from collections import Counter

BASE = os.environ.get("UCEC_RAW_DIR", ".")

def patient_id(sample_barcode):
    return "-".join(sample_barcode.split("-")[:3])

def header_samples(path):
    with gzip.open(path, "rt") as f:
        header = f.readline().rstrip("\n").split("\t")
    return set(patient_id(s) for s in header[1:])

def mutation_samples(path):
    ids = set()
    with gzip.open(path, "rt") as f:
        r = csv.reader(f, delimiter="\t")
        next(r)
        for row in r:
            ids.add(patient_id(row[0]))
    return ids

def clinical_samples(path):
    ids = set()
    with gzip.open(path, "rt") as f:
        r = csv.reader(f, delimiter="\t")
        header = next(r)
        idx = header.index("sample")
        for row in r:
            ids.add(patient_id(row[idx]))
    return ids

def subtype_map(path):
    m = {}
    with open(path) as f:
        r = csv.reader(f, delimiter="\t")
        next(r)
        for row in r:
            m[row[0]] = row[1]
    return m

sets = {
    "rna_seq": header_samples(f"{BASE}/TCGA-UCEC.star_fpkm.tsv.gz"),
    "mirna": header_samples(f"{BASE}/TCGA-UCEC.mirna.tsv.gz"),
    "methylation": header_samples(f"{BASE}/TCGA-UCEC.methylation450.tsv.gz"),
    "cnv": header_samples(f"{BASE}/TCGA-UCEC.gene-level_ascat3.tsv.gz"),
    "mutation": mutation_samples(f"{BASE}/TCGA-UCEC.somaticmutation_wxs.tsv.gz"),
    "clinical": clinical_samples(f"{BASE}/TCGA-UCEC.clinical.tsv.gz"),
}
subtype = subtype_map(f"{BASE}/TCGA-UCEC.molecular_subtype.tsv")

cohort = (sets["rna_seq"] & sets["mirna"] & sets["methylation"] & sets["cnv"]
          & sets["mutation"] & sets["clinical"] & set(subtype.keys()))
cohort = sorted(cohort)

with open(f"{BASE}/final_cohort.tsv", "w") as f:
    f.write("patientId\tsubtype\n")
    for p in cohort:
        f.write(f"{p}\t{subtype[p]}\n")

summary = {
    "n_patients": len(cohort),
    "subtype_counts": dict(Counter(subtype[p] for p in cohort)),
    "modalities_required": list(sets.keys()) + ["subtype_label"],
    "policy": "strict intersection across all 5 omics + clinical + subtype label",
}
with open(f"{BASE}/final_cohort_summary.json", "w") as f:
    json.dump(summary, f, indent=2)

print(json.dumps(summary, indent=2))
