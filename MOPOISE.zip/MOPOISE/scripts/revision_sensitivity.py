"""Aggregate the revision sensitivity runs: prefilter size (k = 250, 1,000) and assay-specific costs.

Tagged runs in results_rev/<ALG>_<tag>/ are paired by run index with the main runs in results/<ALG>/.
For the prefilter runs, the filter fronts are those rebuilt with the same k (results_rev/k<k>/...).
For the cost runs, the hypervolume of the main filter fronts is recomputed with the assay-specific
costs from the blocks of each panel; the panels and their scores do not change.
Writes results_rev/sensitivity/sensitivity.tsv and prints LaTeX rows.
"""
from __future__ import annotations

import glob
import json
from collections import Counter
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

from mopoise.aggregate import load_run
from mopoise.search import hypervolume
from mopoise.selection import nondominated, one_se_rule

ALGS = {"SPEA2": "MO-POISE-SPEA2", "SMSEMOA": "MO-POISE-SMS-EMOA", "OMNI": "MO-POISE-Omni-optimizer"}
TAGS = {"_k250": "250 candidates per block", "_k1000": "1,000 candidates per block", "_wcost": "assay-specific costs"}
WEIGHTS = {"rna": 1.1, "mirna": 0.8, "meth": 0.9, "cnv": 0.3, "mut": 1.9, "clin": 0.0}
OUT = Path("results_rev/sensitivity")


def r(x, d=3):
    return str(Decimal(repr(float(x))).quantize(Decimal("1." + "0" * d), ROUND_HALF_UP))


def run_row(f):
    d = load_run(f)
    fr = d["front"]
    sel = fr[d["selected"]["one_se"]]
    err = np.array([p["inner_error"] for p in fr]); se = np.array([p["inner_error_se"] for p in fr])
    cost = np.array([p["assay_cost"] for p in fr]); size = np.array([p["size"] for p in fr])
    i5 = one_se_rule(err, se, cost, size, candidates=np.flatnonzero(size <= 5))
    omics = [b for b in sel["blocks"] if b != "clin"]
    return {"run": (d["seed"] - 2026) // 98, "fold": d["fold"], "hv": d["hypervolume"]["test"],
            "f1": sel["test"]["macro_f1"], "n_assays": len(omics), "wcost": sum(WEIGHTS[b] for b in omics),
            "blocks": "+".join(sorted(omics)), "size": sel["size"],
            "f1_k5": fr[i5]["test"]["macro_f1"] if i5 is not None else np.nan,
            "minutes": d["search_seconds"] / 60}


def filter_hv(path, weights=None):
    P = json.load(open(path))["panels"]
    N = json.load(open(path))["N"]
    if weights is None:
        cost = np.array([p["assay_cost"] for p in P]); total = 5.0
    else:
        cost = np.array([sum(weights[b] for b in p["used_blocks"]) for p in P]); total = sum(weights.values())
    size = np.array([p["size"] for p in P])
    Fi = np.column_stack([[p["inner_error"] for p in P], cost, size / N])
    Ft = np.column_stack([[1 - p["test"]["macro_f1"] for p in P], cost, size / N])[nondominated(Fi)]
    return hypervolume(Ft[nondominated(Ft)], total)   # inner non-dominated panels, as for the searches


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for alg, label in ALGS.items():
        main_runs = pd.DataFrame([run_row(f) for f in glob.glob(f"results/{alg}/fold*_seed*.json")]).set_index("run")
        for tag, setting in TAGS.items():
            files = glob.glob(f"results_rev/{alg}{tag}/fold*_seed*.json")
            if len(files) < 20:
                print(f"{alg}{tag}: only {len(files)} runs, skipped"); continue
            t = pd.DataFrame([run_row(f) for f in files]).set_index("run").sort_index()
            m = main_runs.loc[t.index]
            if tag == "_wcost":
                base = {k: filter_hv(f"results/baselines/fold{k}.json", WEIGHTS) for k in range(5)}
                base_main = {k: filter_hv(f"results/baselines/fold{k}.json") for k in range(5)}
            else:
                k = tag[2:]
                base = {f: filter_hv(f"results_rev/k{k}/baselines/fold{f}.json") for f in range(5)}
            d = t.hv.values - np.array([base[f] for f in t.fold])
            row = {"algorithm": label, "setting": setting, "hv_main": m.hv.mean(), "hv": t.hv.mean(),
                   "p_hv": wilcoxon(t.hv, m.hv).pvalue, "delta_anova": d.mean(), "runs_below_anova": int((d < 0).sum()),
                   "f1_main": m.f1.mean(), "f1": t.f1.mean(), "p_f1": wilcoxon(t.f1, m.f1).pvalue,
                   "assays_main": m.n_assays.mean(), "assays": t.n_assays.mean(),
                   "wcost_main": m.wcost.mean(), "wcost": t.wcost.mean(), "p_wcost": wilcoxon(t.wcost, m.wcost).pvalue,
                   "f1_k5_main": m.f1_k5.mean(), "f1_k5": t.f1_k5.mean(),
                   "minutes": t.minutes.mean(), "blocks": dict(Counter(t.blocks).most_common(4)),
                   "blocks_main": dict(Counter(m.blocks).most_common(4)),
                   "mut_share": float(np.mean(["mut" in b for b in t.blocks])),
                   "mut_share_main": float(np.mean(["mut" in b for b in m.blocks]))}
            if tag == "_wcost":
                row["anova_hv_weighted"] = np.mean(list(base.values())); row["anova_hv_equal"] = np.mean(list(base_main.values()))
            rows.append(row)
    df = pd.DataFrame(rows)
    df.to_csv(OUT / "sensitivity.tsv", sep="\t", index=False)
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)
    print(df.drop(columns=["blocks", "blocks_main"]).to_string(index=False))
    for _, x in df.iterrows():
        print(x.algorithm, x.setting, "blocks:", x.blocks, "| main:", x.blocks_main)
    print("\nLaTeX rows (Table sensitivity):")
    for _, x in df.iterrows():
        p = "$<$0.001" if x.p_hv < 0.001 else r(x.p_hv)
        print(f"{x.algorithm} | \\quad {x.setting} & {r(x.hv_main)} & {r(x.hv)} & {p} & ${r(x.delta_anova)}$ & {r(x.f1)} & {r(x.minutes, 1)} \\\\")


if __name__ == "__main__":
    main()
