"""Summarize the runs with the aggregate readouts in the candidate pool (results_rev/<ALG>_agg, results_rev/agg/).

Compared with the main runs (kappa from results_rev/posthoc) and with the molecular surrogate of the same fold.
"""
import glob
import json
from decimal import ROUND_HALF_UP, Decimal

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

from mopoise.aggregate import load_run
from mopoise.selection import one_se_rule, per_cost_rule

ALGS = {"SPEA2": "MO-POISE-SPEA2", "SMSEMOA": "MO-POISE-SMS-EMOA", "OMNI": "MO-POISE-Omni-optimizer"}
AGG = ("mut:POLE_hotspot", "mut:MMR_truncating", "meth:MLH1_promoter")


def r(x, d=3):
    return str(Decimal(repr(float(x))).quantize(Decimal("1." + "0" * d), ROUND_HALF_UP))


def picks(P):
    err = np.array([p["inner_error"] for p in P]); se = np.array([p["inner_error_se"] for p in P])
    cost = np.array([p["assay_cost"] for p in P]); size = np.array([p["size"] for p in P])
    out = {"one_se": one_se_rule(err, se, cost, size),
           "size5": one_se_rule(err, se, cost, size, candidates=np.flatnonzero(size <= 5))}
    pc = per_cost_rule(err, se, cost, size); ks = [k for k in pc if k <= 2]
    out["budget2"] = pc[max(ks)] if ks else None
    return out


post = pd.concat([pd.read_csv(f, sep="\t") for f in glob.glob("results_rev/posthoc/posthoc_fold*.tsv")])
post = post[post.classifier.isin(["LR", "rule"])]
sur = post[post.method == "surrogate"].set_index("fold")
rows = []
for alg, name in ALGS.items():
    for f in sorted(glob.glob(f"results_rev/{alg}_agg/fold*_seed*.json")):
        d = load_run(f); fr = d["front"]
        row = {"alg": name, "fold": d["fold"], "seed": d["seed"], "hv": d["hypervolume"]["test"]}
        main = load_run(f"results/{alg}/fold{d['fold']}_seed{d['seed']}.json")
        row["hv_main"] = main["hypervolume"]["test"]
        for kind, i in picks(fr).items():
            if i is None:
                continue
            p = fr[i]
            row[f"{kind}_f1"], row[f"{kind}_kappa"] = p["test"]["macro_f1"], p["test"]["kappa"]
            row[f"{kind}_size"], row[f"{kind}_assays"] = p["size"], p["assay_cost"]
            row[f"{kind}_blocks"] = "+".join(b for b in p["blocks"] if b != "clin")
            for a in AGG:
                row[f"{kind}_has_{a.split(':')[1]}"] = a in p["features"]
            m = post[(post.method == alg) & (post.seed == d["seed"]) & (post.panel == kind)]
            row[f"{kind}_f1_main"] = m.macro_f1.iloc[0]; row[f"{kind}_kappa_main"] = m.kappa.iloc[0]
        row["sur_f1"], row["sur_kappa"] = sur.loc[d["fold"], "macro_f1"], sur.loc[d["fold"], "kappa"]
        rows.append(row)
D = pd.DataFrame(rows)
print("runs per algorithm:", D.groupby("alg").size().to_dict())
pd.set_option("display.width", 250)
for kind in ("one_se", "size5", "budget2"):
    print(f"\n== {kind}")
    g = D.groupby("alg")
    t = pd.DataFrame({"f1_main": g[f"{kind}_f1_main"].mean(), "f1_agg": g[f"{kind}_f1"].mean(),
                      "kappa_main": g[f"{kind}_kappa_main"].mean(), "kappa_agg": g[f"{kind}_kappa"].mean(),
                      "size_med": g[f"{kind}_size"].median(), "assays": g[f"{kind}_assays"].mean(),
                      **{f"has_{a.split(':')[1]}": g[f"{kind}_has_{a.split(':')[1]}"].mean() for a in AGG}})
    print(t.round(3))
    x = D.dropna(subset=[f"{kind}_kappa"])
    print("  all three: f1 main", r(x[f"{kind}_f1_main"].mean()), "agg", r(x[f"{kind}_f1"].mean()),
          "| kappa main", r(x[f"{kind}_kappa_main"].mean()), "agg", r(x[f"{kind}_kappa"].mean()),
          "| p kappa", r(wilcoxon(x[f"{kind}_kappa"], x[f"{kind}_kappa_main"]).pvalue, 4),
          "| vs surrogate kappa", r(x.sur_kappa.mean()), "p", r(wilcoxon(x[f"{kind}_kappa"], x.sur_kappa).pvalue, 4),
          "| runs >= surrogate", int((x[f"{kind}_kappa"] >= x.sur_kappa).sum()), "of", len(x))
    print("  blocks:", x[f"{kind}_blocks"].value_counts().head(4).to_dict())
print("\nHV main", r(D.hv_main.mean()), "agg", r(D.hv.mean()), "p", r(wilcoxon(D.hv, D.hv_main).pvalue, 4))
print("surrogate F1", r(sur.macro_f1.mean()), "kappa", r(sur.kappa.mean()))

print("\n== filter fronts with aggregates (LR)")
for m, dname in (("anova", "baselines"), ("mrmr", "baselines_mrmr"), ("l1", "baselines_l1")):
    acc = {}
    for f in sorted(glob.glob(f"results_rev/agg/{dname}/fold*.json")):
        P = json.load(open(f))["panels"]
        for kind, i in picks(P).items():
            if i is not None:
                acc.setdefault(kind, []).append((P[i]["test"]["macro_f1"], P[i]["test"]["kappa"], P[i]["size"]))
    print(m, {k: (r(np.mean([v[0] for v in vals])), r(np.mean([v[1] for v in vals])), int(np.median([v[2] for v in vals])))
              for k, vals in acc.items()})
