# MO-POISE

**MO-POISE** (Multi-Objective Plug-and-play Optimizer for Imbalance-aware Subtyping
of Endometrial cancer) poses the reconstruction of the four TCGA molecular subtypes
of endometrial carcinoma (TCGA-UCEC) from multi-omics data as a three-objective
feature-selection problem. The problem is searched with multi-objective evolutionary
algorithms (MOEAs) inside leakage-controlled nested cross-validation. Any MOEA plugs
into the same problem, operators and evaluation; the pipeline with MOEA X is called
MO-POISE-X, for example MO-POISE-NSGA-II.

## Objectives

All three objectives are minimized.

| Objective | Definition |
|---|---|
| error | 1 - mean inner-CV macro-F1 (logistic regression, 3 inner folds) |
| assay cost | number of omics assays that contribute at least one feature (1 per omics assay, 0 for clinical data) |
| size | number of selected features / N |

## Method in brief

* **Nested cross-validation**: five stratified outer folds with one fixed partition.
  In each outer training fold, an ANOVA prefilter keeps the top 500 features of every
  omics block plus 5 clinical variables (N = 2,505 candidates).
* **Operators** (`mopoise/search.py`): block-sparse initialization, uniform crossover,
  and a mutation that can drop a whole data block.
* **Training-side panel choice** (`mopoise/selection.py`): the one-standard-error rule,
  the same rule per assay budget, and per maximum panel size. Outer-test scores are
  reported for the whole front but never used to choose a panel.
* **Filter reference fronts** (`mopoise/baselines.py`): every subset of the six data
  blocks combined with ANOVA top-m, mRMR top-m, or the supports of an L1
  logistic-regression path.

## Algorithms

Fourteen MOEAs: `NSGA2 NSGA3 UNSGA3 SPEA2 MOEAD RVEA SMSEMOA AGEMOEA AGEMOEA2 OMNI`
(from pymoo 0.6.2) and `NRVMOEA MOBCA TELSO IMCMOEAD` (in `mopoise/moeas/`).

## Layout

```
mopoise/data.py          cohort loader and label-free data cache
mopoise/prefilter.py     in-fold ANOVA top-k per block
mopoise/objectives.py    panel evaluator: inner CV, three objectives, cache
mopoise/search.py        problem definition, shared operators, pymoo algorithms, hypervolume
mopoise/moeas/           further MOEAs and shared utilities
mopoise/selection.py     non-dominated filter, one-SE and per-budget rules
mopoise/nested_cv.py     one (algorithm, fold, seed) unit -> results/<ALG>/fold<k>_seed<s>.json
mopoise/baselines.py     filter fronts per fold -> results/baselines{,_l1,_mrmr}/fold<k>.json
mopoise/aggregate.py     tables and statistics -> results/summary/
mopoise/synthetic.py     synthetic data with the shape of the cohort, for smoke runs
scripts/build_cohort.py  cohort table from the raw files
run_all.sh               all filter fronts and all algorithm runs
results/                 per-run results of the study (see below)
```

## Data

Download the following TCGA-UCEC files from the GDC hub of UCSC Xena
(https://xenabrowser.net) into one directory:

```
TCGA-UCEC.star_fpkm.tsv.gz             gene expression
TCGA-UCEC.mirna.tsv.gz                 miRNA expression
TCGA-UCEC.methylation450.tsv.gz        DNA methylation (450K)
TCGA-UCEC.gene-level_ascat3.tsv.gz     gene-level copy number
TCGA-UCEC.somaticmutation_wxs.tsv.gz   somatic mutations
TCGA-UCEC.clinical.tsv.gz              clinical data
```

Add `TCGA-UCEC.molecular_subtype.tsv`, a tab-separated file with a header line,
the patient barcode in the first column and the molecular subtype of the
PanCancer Atlas endometrial study in cBioPortal (https://www.cbioportal.org) in
the second column.

## Reproducing

    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt

    export UCEC_RAW_DIR=/path/to/raw
    python scripts/build_cohort.py                  # writes $UCEC_RAW_DIR/final_cohort.tsv
    python -m mopoise.data --build                  # label-free cache in ./data
    JOBS=8 OMP_NUM_THREADS=2 ./run_all.sh           # filter fronts + all algorithms x 20 runs
    JOBS=4 OMP_NUM_THREADS=4 ./run_all.sh NSGA2     # a subset of algorithms
    python -m mopoise.aggregate                     # results/summary/

Run i uses outer fold i // 4 and seed 2026 + 98 i. Units whose result file already
exists are skipped, so the shipped results are kept unless `--force` is given.
The sensitivity analyses rerun NSGA2 and SMSEMOA with
`--density-max 1.0 --tag _dens1` and with `--max-evals 20000 --tag _20k`, for example

    python -m mopoise.nested_cv --algorithm NSGA2 --run 0 --density-max 1.0 --tag _dens1

A smoke run on synthetic data needs no download:

    UCEC_RESULTS_DIR=/tmp/mopoise_smoke python -m mopoise.nested_cv \
        --algorithm NSGA2 --run 0 --synthetic --max-evals 600

## Results

* `results/<ALG>/fold<k>_seed<s>.json`: final front of every run with inner and
  outer-test scores of every panel, the selected panels, and the convergence curve.
* `results/baselines/`, `results/baselines_mrmr/`, `results/baselines_l1/`: the
  ANOVA, mRMR, and L1 filter fronts of every outer fold.
* `results/<ALG>_dens1/`, `results/<ALG>_20k/`: the sensitivity analyses.
* `results/summary/`: tables and statistics produced by `python -m mopoise.aggregate`.

## License

MIT, see `LICENSE`.
