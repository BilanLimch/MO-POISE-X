"""Aggregate results_rev/posthoc into the revision tables (per-class precision/recall, classifiers, surrogate)."""
from __future__ import annotations

import glob
from decimal import ROUND_HALF_UP, Decimal

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

NAMES = {"SPEA2": "MO-POISE-SPEA2", "SMSEMOA": "MO-POISE-SMS-EMOA", "OMNI": "MO-POISE-Omni-optimizer"}
COMPETITIVE = ("SPEA2", "SMSEMOA", "OMNI", "NSGA2", "AGEMOEA", "AGEMOEA2", "NSGA3", "UNSGA3", "RVEA", "NRVMOEA")
FILTERS = {"anova": "ANOVA filter front", "mrmr": "mRMR filter front", "l1": "L1 filter front"}
CLASSES = ("UCEC_POLE", "UCEC_MSI", "UCEC_CN_LOW", "UCEC_CN_HIGH")


def r(x, d=3):
    return str(Decimal(repr(float(x))).quantize(Decimal("1." + "0" * d), ROUND_HALF_UP))


def rev(x):
    return "\\rev{" + x + "}"


D = pd.concat([pd.read_csv(f, sep="\t") for f in sorted(glob.glob("results_rev/posthoc/posthoc_fold*.tsv"))])
groups = {**{NAMES[a]: D.method == a for a in NAMES}, "Ten competitive": D.method.isin(COMPETITIVE),
          **{FILTERS[m]: D.method == m for m in FILTERS}}
sur = D[D.method == "surrogate"]

print("== per-class precision/recall, one-SE panel, LR")
for name, g in list(groups.items()) + [("Molecular surrogate", D.method == "surrogate")]:
    x = D[g & (D.panel.isin(["one_se", "rule"])) & (D.classifier.isin(["LR", "rule"]))]
    cells = []
    for c in CLASSES:
        cells += [r(x[f"precision_{c}"].mean()), r(x[f"recall_{c}"].mean())]
    cells.append(r(x.kappa.mean()))
    print(f"{name} & " + " & ".join(rev(c) for c in cells) + f" \\\\   % n={len(x)} macroF1={r(x.macro_f1.mean())}")

print("\n== kappa range per algorithm (one-SE, LR)")
k = D[(D.panel == "one_se") & (D.classifier == "LR")].groupby("method").kappa.mean()
print(k.round(3).to_dict())

print("\n== classifiers (macro-F1)")
for name, g in groups.items():
    cells = []
    for panel in ("one_se", "size5", "budget2"):
        for clf in ("LR", "RF", "SVM"):
            x = D[g & (D.panel == panel) & (D.classifier == clf)]
            cells.append(r(x.macro_f1.mean()))
    print(f"{name} & " + " & ".join(rev(c) for c in cells) + " \\\\")

print("\n== per-algorithm one-SE macro-F1 by classifier (ten competitive range)")
t = D[D.method.isin(COMPETITIVE) & (D.panel == "one_se")].groupby(["method", "classifier"]).macro_f1.mean().unstack()
print(t.round(3)); print("range:", t.min().round(3).to_dict(), t.max().round(3).to_dict())

print("\n== paired: evolutionary k<=5 vs filter k<=5 per classifier (ten competitive mean minus filter, by fold)")
for clf in ("LR", "RF", "SVM"):
    for panel in ("size5", "one_se", "budget2"):
        ev = D[D.method.isin(COMPETITIVE) & (D.panel == panel) & (D.classifier == clf)].groupby("fold").macro_f1.mean()
        out = []
        for m in FILTERS:
            f = D[(D.method == m) & (D.panel == panel) & (D.classifier == clf)].set_index("fold").macro_f1
            out.append(f"{m} {r((ev - f).mean())}")
        print(clf, panel, "evo-minus-filter:", ", ".join(out))

print("\n== surrogate by fold")
print(sur[["fold", "macro_f1", "kappa", "accuracy"]].round(3).to_string(index=False))
print("surrogate mean macro-F1", r(sur.macro_f1.mean()), "kappa", r(sur.kappa.mean()))
for panel in ("size5", "one_se", "budget2"):
    x = D[D.method.isin(COMPETITIVE) & (D.panel == panel) & (D.classifier == "LR")]
    print(panel, "ten competitive LR macroF1", r(x.macro_f1.mean()), "kappa", r(x.kappa.mean()),
          "| best alg kappa", r(x.groupby("method").kappa.mean().max()))
    # paired by fold: surrogate vs per-run panels
    xs = x.merge(sur[["fold", "macro_f1", "kappa"]], on="fold", suffixes=("", "_sur"))
    print("   runs with kappa >= surrogate of their fold:", int((xs.kappa >= xs.kappa_sur).sum()), "of", len(xs))
for m in FILTERS:
    for panel in ("one_se", "budget2"):
        x = D[(D.method == m) & (D.panel == panel) & (D.classifier == "LR")]
        print(m, panel, "macroF1", r(x.macro_f1.mean()), "kappa", r(x.kappa.mean()))
