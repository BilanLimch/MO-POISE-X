"""Block-sparse versus flat sparse initialization for the ten competitive algorithms (revision).

Main runs: results/<ALG>/. Flat runs: results/<ALG>_flat/ for SPEA2, SMSEMOA, OMNI (first ablation)
and results_rev/<ALG>_flat/ for the other seven. Paired by run index; two-sided Wilcoxon signed-rank tests.
Writes results_rev/ablation/ablation_all.tsv and prints LaTeX rows.
"""
from __future__ import annotations

import glob
import json
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

NAMES = {"SPEA2": "MO-POISE-SPEA2", "SMSEMOA": "MO-POISE-SMS-EMOA", "OMNI": "MO-POISE-Omni-optimizer",
         "NSGA2": "MO-POISE-NSGA-II", "RVEA": "MO-POISE-RVEA", "UNSGA3": "MO-POISE-U-NSGA-III",
         "AGEMOEA2": "MO-POISE-AGE-MOEA-II", "NRVMOEA": "MO-POISE-NRV-MOEA", "AGEMOEA": "MO-POISE-AGE-MOEA",
         "NSGA3": "MO-POISE-NSGA-III"}   # order of Table main


def r(x, d=3):
    return str(Decimal(repr(float(x))).quantize(Decimal("1." + "0" * d), ROUND_HALF_UP))


def pv(p):
    return "$<$0.001" if p < 0.001 else r(p)


def load(pattern):
    rows = {}
    for f in glob.glob(pattern):
        d = json.load(open(f))
        s = d["front"][d["selected"]["one_se"]]
        rows[(d["seed"] - 2026) // 98] = {"hv": d["hypervolume"]["test"], "f1": s["test"]["macro_f1"],
                                          "assays": len([b for b in s["blocks"] if b != "clin"]), "size": s["size"]}
    return pd.DataFrame(rows).T.sort_index()


out = []
for alg, name in NAMES.items():
    m = load(f"results/{alg}/fold*_seed*.json")
    flat_dir = f"results/{alg}_flat" if alg in ("SPEA2", "SMSEMOA", "OMNI") else f"results_rev/{alg}_flat"
    t = load(f"{flat_dir}/fold*_seed*.json")
    if len(t) < 20:
        print(alg, "only", len(t), "flat runs"); continue
    m = m.loc[t.index]
    row = {"algorithm": name, "hv_block": m.hv.mean(), "hv_flat": t.hv.mean(), "p_hv": wilcoxon(t.hv, m.hv).pvalue,
           "as_block": m.assays.mean(), "as_flat": t.assays.mean(),
           "p_as": wilcoxon(t.assays, m.assays).pvalue if (t.assays != m.assays).any() else 1.0,
           "f1_block": m.f1.mean(), "f1_flat": t.f1.mean(), "p_f1": wilcoxon(t.f1, m.f1).pvalue,
           "size_block": float(np.median(m["size"])), "size_flat": float(np.median(t["size"])),
           "runs_hv_higher": int((m.hv.values > t.hv.values).sum())}
    out.append(row)
df = pd.DataFrame(out)
Path("results_rev/ablation").mkdir(parents=True, exist_ok=True)
df.to_csv("results_rev/ablation/ablation_all.tsv", sep="\t", index=False)
pd.set_option("display.width", 220)
print(df.round(4).to_string(index=False))
for _, x in df.iterrows():
    print(f"\\rev{{{x.algorithm}}} & \\rev{{{r(x.hv_block)}}} & \\rev{{{r(x.hv_flat)}}} & \\rev{{{pv(x.p_hv)}}} & "
          f"\\rev{{{r(x.as_block, 2)}}} & \\rev{{{r(x.as_flat, 2)}}} & \\rev{{{pv(x.p_as)}}} & "
          f"\\rev{{{r(x.f1_block)}}} & \\rev{{{r(x.f1_flat)}}} & \\rev{{{pv(x.p_f1)}}} \\\\")
