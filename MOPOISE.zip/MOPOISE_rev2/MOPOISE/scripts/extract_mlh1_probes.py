"""Write data/mlh1_probes.tsv: the 450K probes annotated to MLH1 in the GDC probe map.

Input: HM450.hg38.manifest.gencode.v36.probeMap from the GDC hub of UCSC Xena.
Usage: python scripts/extract_mlh1_probes.py /path/to/HM450.hg38.manifest.gencode.v36.probeMap
"""
import csv
import os
import sys
from pathlib import Path

out = Path(os.environ.get("UCEC_CACHE_DIR", "data")) / "mlh1_probes.tsv"
rows = list(csv.reader(open(sys.argv[1]), delimiter="\t"))
keep = [r for r in rows[1:] if "MLH1" in r[1].split(",")]
out.parent.mkdir(parents=True, exist_ok=True)
with open(out, "w", newline="") as f:
    w = csv.writer(f, delimiter="\t", lineterminator="\n")
    w.writerow(["id", "gene", "chrom", "chromStart", "chromEnd", "strand"])
    w.writerows(keep)
print(f"{len(keep)} probes -> {out}")
