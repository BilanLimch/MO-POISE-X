"""Re-score the final fronts on repeated inner partitions before choosing a panel (revision).

For every run on one outer fold, every panel of the stored final front is scored again by
logistic regression on R = 5 repetitions of a stratified three-fold partition of the outer
training fold, drawn with a seed that differs from the partition used in the search. The
one-standard-error rule and the size-capped rule (k <= 5) are then applied to the re-scored
inner errors, and the outer-test score of the chosen panel is taken from the stored front.
No search is repeated.

Usage: python scripts/revision_rescore.py --fold 0 --out results_rev/rescore
"""
from __future__ import annotations

import argparse
import glob
import json
from pathlib import Path

import numpy as np
import pandas as pd

from mopoise.data import load_dataset
from mopoise.nested_cv import RESULTS_DIR, outer_folds
from mopoise.objectives import ObjectiveConfig, PanelEvaluator
from mopoise.prefilter import PrefilterConfig, fit_feature_pool
from mopoise.selection import one_se_rule

ALGORITHMS = ("SPEA2", "SMSEMOA", "OMNI", "NSGA2", "AGEMOEA", "AGEMOEA2", "NSGA3", "UNSGA3", "RVEA",
              "NRVMOEA", "MOBCA", "IMCMOEAD", "TELSO")
REPEATS = 5
SEED_OFFSET = 100_003   # the re-scoring partition differs from the search partition (seed of the run)


def main(fold: int, out: Path, results: Path):
    ds = load_dataset()
    train_idx, _ = outer_folds(ds)[fold]
    y_tr = ds.y[train_idx]
    pool = fit_feature_pool(ds, train_idx, PrefilterConfig(k_per_block=500))
    X_tr = pool.transform(ds, train_idx)
    col = {n: i for i, n in enumerate(pool.feature_names)}
    rows = []
    for alg in ALGORITHMS:
        for f in sorted(glob.glob(str(results / alg / f"fold{fold}_seed*.json"))):
            r = json.load(open(f))
            fr = r["front"]
            ev = PanelEvaluator(X_tr, y_tr, pool.block_slices,
                                ObjectiveConfig(n_inner_repeats=REPEATS, random_state=r["seed"] + SEED_OFFSET))
            masks = []
            for p in fr:
                m = np.zeros(pool.n_features, dtype=bool)
                m[[col[n] for n in p["features"]]] = True
                masks.append(m)
            sc = [ev.score(m) for m in masks]
            cost = np.array([p["assay_cost"] for p in fr]); size = np.array([p["size"] for p in fr])
            err0 = np.array([p["inner_error"] for p in fr]); se0 = np.array([p["inner_error_se"] for p in fr])
            err1 = np.array([s.error for s in sc]); se1 = np.array([s.error_se for s in sc])
            test = np.array([p["test"]["macro_f1"] for p in fr])
            row = {"algorithm": alg, "fold": fold, "seed": r["seed"], "front_size": len(fr)}
            for tag, err, se in (("search", err0, se0), ("rescored", err1, se1)):
                for rule, cand in (("one_se", None), ("size5", np.flatnonzero(size <= 5))):
                    i = one_se_rule(err, se, cost, size, candidates=cand)
                    if i is None:
                        continue
                    row[f"{tag}_{rule}_inner"] = 1 - err[i]
                    row[f"{tag}_{rule}_test"] = test[i]
                    row[f"{tag}_{rule}_gap"] = (1 - err[i]) - test[i]
                    row[f"{tag}_{rule}_size"] = int(size[i])
                    row[f"{tag}_{rule}_cost"] = float(cost[i])
                    # independent re-scored estimate of the panel chosen with the search scores
                    row[f"{tag}_{rule}_inner_indep"] = 1 - err1[i]
            row["front_gap_search"] = float(np.mean((1 - err0) - test))
            row["front_gap_rescored"] = float(np.mean((1 - err1) - test))
            rows.append(row)
        print(f"fold{fold} {alg}: done", flush=True)
    out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out / f"rescore_fold{fold}.tsv", sep="\t", index=False)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--fold", type=int, required=True)
    ap.add_argument("--out", type=Path, default=Path("results_rev/rescore"))
    ap.add_argument("--results", type=Path, default=RESULTS_DIR)
    a = ap.parse_args()
    main(a.fold, a.out, a.results)
