"""Label-free aggregate readouts of the clinical surrogate classification, per patient.

mut:POLE_hotspot       pathogenic POLE exonuclease-domain hotspot mutation (11 variants), binary
mut:MMR_truncating     truncating mutation of MLH1, MSH2, MSH6, or PMS2, binary
meth:MLH1_promoter     mean beta value of the probes in the CpG island shared by MLH1 and EPM2AIP1

No label is used. Usage:
    python scripts/build_aggregates.py --out data/ucec_aggregates.npz
(reads $UCEC_RAW_DIR/TCGA-UCEC.somaticmutation_wxs.tsv.gz and $UCEC_CACHE_DIR/{cohort.tsv,ucec_meth.npz,mlh1_probes.tsv})
"""
import argparse
import os
from pathlib import Path

import numpy as np
import pandas as pd

from mopoise.data import CACHE_DIR, load_dataset, pick_primary_samples

POLE_HOTSPOTS = {"p.P286R", "p.V411L", "p.S297F", "p.A456P", "p.S459F", "p.F367S", "p.L424I",
                 "p.M295R", "p.P436R", "p.M444K", "p.D368Y"}
TRUNCATING = {"stop_gained", "frameshift_variant", "splice_acceptor_variant", "splice_donor_variant"}

ap = argparse.ArgumentParser()
ap.add_argument("--out", type=Path, default=CACHE_DIR / "ucec_aggregates.npz")
a = ap.parse_args()
ds = load_dataset(("meth",))
raw = pd.read_csv(Path(os.environ.get("UCEC_RAW_DIR", "raw")) / "TCGA-UCEC.somaticmutation_wxs.tsv.gz", sep="\t",
                  usecols=["sample", "gene", "Amino_Acid_Change", "effect"], dtype=str)
chosen = pick_primary_samples(sorted(raw["sample"].unique()), list(ds.patients))
raw = raw[raw["sample"].isin(set(chosen.values()))].copy()
raw["patient"] = raw["sample"].map({bc: p for p, bc in chosen.items()})
trunc = raw["effect"].fillna("").str.split(";").map(lambda t: any(x in TRUNCATING for x in t))
pole = set(raw.loc[(raw["gene"] == "POLE") & raw["Amino_Acid_Change"].isin(POLE_HOTSPOTS), "patient"])
mmr = set(raw.loc[raw["gene"].isin(["MLH1", "MSH2", "MSH6", "PMS2"]) & trunc, "patient"])
probes = pd.read_csv(CACHE_DIR / "mlh1_probes.tsv", sep="\t")
promoter = probes.loc[probes["gene"].str.contains("EPM2AIP1") & probes["gene"].str.contains("MLH1"), "id"]
meth = ds.blocks["meth"]
beta = np.nanmean(meth.X[:, np.isin(meth.features, list(promoter))], axis=1)
mut_X = np.column_stack([np.isin(ds.patients, list(pole)), np.isin(ds.patients, list(mmr))]).astype(np.float32)
np.savez_compressed(a.out, patients=ds.patients.astype(str),
                    mut_X=mut_X, mut_features=np.array(["POLE_hotspot", "MMR_truncating"]),
                    meth_X=beta[:, None].astype(np.float32), meth_features=np.array(["MLH1_promoter"]))
print(f"{a.out}: POLE hotspot {int(mut_X[:, 0].sum())}, MMR truncating {int(mut_X[:, 1].sum())}, "
      f"MLH1 promoter beta median {np.median(beta):.3f}")
