"""Summarize results_rev/rescore: generalization gap and outer-test accuracy of the panels chosen
with the search scores and with the re-scored inner errors (revision)."""
import glob
from decimal import ROUND_HALF_UP, Decimal

import pandas as pd
from scipy.stats import wilcoxon

COMP = ("SPEA2", "SMSEMOA", "OMNI", "NSGA2", "AGEMOEA", "AGEMOEA2", "NSGA3", "UNSGA3", "RVEA", "NRVMOEA")


def r(x, d=3):
    return str(Decimal(repr(float(x))).quantize(Decimal("1." + "0" * d), ROUND_HALF_UP))


D = pd.concat([pd.read_csv(f, sep="\t") for f in sorted(glob.glob("results_rev/rescore/rescore_fold*.tsv"))])
C = D[D.algorithm.isin(COMP)]
print("runs:", len(D), "competitive:", len(C))
for rule in ("one_se", "size5"):
    x = C.dropna(subset=[f"search_{rule}_test", f"rescored_{rule}_test"])
    print(f"\n== {rule} (ten competitive, n={len(x)})")
    for tag in ("search", "rescored"):
        print(f"  {tag:9s} inner {r(x[f'{tag}_{rule}_inner'].mean())}  test {r(x[f'{tag}_{rule}_test'].mean())}  "
              f"gap {r(x[f'{tag}_{rule}_gap'].mean())}  size med {x[f'{tag}_{rule}_size'].median()}  "
              f"assays {r(x[f'{tag}_{rule}_cost'].mean(), 2)}")
    print("  search-chosen panel, independent re-scored inner:", r(x[f"search_{rule}_inner_indep"].mean()),
          " -> gap", r((x[f"search_{rule}_inner_indep"] - x[f"search_{rule}_test"]).mean()))
    print("  p test (rescored vs search):", r(wilcoxon(x[f"rescored_{rule}_test"], x[f"search_{rule}_test"]).pvalue, 4),
          " p gap:", r(wilcoxon(x[f"rescored_{rule}_gap"], x[f"search_{rule}_gap"]).pvalue, 4),
          " runs with higher test:", int((x[f"rescored_{rule}_test"] > x[f"search_{rule}_test"]).sum()),
          " lower:", int((x[f"rescored_{rule}_test"] < x[f"search_{rule}_test"]).sum()))
print("\n== mean gap over all front panels (ten competitive): search", r(C.front_gap_search.mean()),
      "rescored", r(C.front_gap_rescored.mean()))
print("\n== per algorithm, one-SE: test search -> rescored, gap search -> rescored")
g = C.groupby("algorithm")
t = pd.DataFrame({"test_s": g.search_one_se_test.mean(), "test_r": g.rescored_one_se_test.mean(),
                  "gap_s": g.search_one_se_gap.mean(), "gap_r": g.rescored_one_se_gap.mean()})
print(t.round(3))
